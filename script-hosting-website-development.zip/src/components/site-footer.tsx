import Link from "next/link";

const LINKS = [
  {
    title: "产品",
    items: [
      { label: "浏览脚本", href: "/scripts" },
      { label: "上传脚本", href: "/new" },
      { label: "我的托管", href: "/manage" },
      { label: "API 文档", href: "/docs" },
    ],
  },
  {
    title: "接口",
    items: [
      { label: "GET /api/scripts", href: "/docs#list" },
      { label: "GET /api/raw/:slug", href: "/docs#raw" },
      { label: "POST /api/scripts", href: "/docs#create" },
      { label: "健康检查", href: "/api/health" },
    ],
  },
];

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-line bg-[#080910]">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 md:grid-cols-[1.5fr_1fr_1fr_1.2fr]">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-brand to-[#4c1d95] font-mono text-[13px] font-bold text-white">
              {"{ }"}
            </span>
            <span className="text-[15px] font-semibold text-white">loadbin</span>
          </div>
          <p className="mt-4 max-w-xs text-[13px] leading-relaxed text-zinc-500">
            为 Luau 脚本作者打造的托管平台。粘贴代码，拿到永久 loadstring 链接，源码默认加密保护。
          </p>
          <div className="mt-5 flex items-center gap-2 font-mono text-[11px] text-zinc-500">
            <span className="h-1.5 w-1.5 rounded-full bg-lime" />
            api · edge · 99.98%
          </div>
        </div>

        {LINKS.map((group) => (
          <div key={group.title}>
            <h3 className="text-[11px] font-semibold uppercase tracking-[0.16em] text-zinc-500">
              {group.title}
            </h3>
            <ul className="mt-4 space-y-2.5">
              {group.items.map((item) => (
                <li key={item.label}>
                  <Link
                    href={item.href}
                    className="text-[13px] text-zinc-400 transition-colors hover:text-brand-2"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}

        <div className="rounded-xl border border-line bg-panel/60 p-4">
          <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-zinc-500">快速开始</p>
          <pre className="mt-3 overflow-x-auto font-mono text-[11.5px] leading-relaxed text-zinc-400">
            <code>
              <span className="text-violet-300">loadstring</span>
              {"(game:HttpGet("}
              <span className="text-lime-300">&quot;…/api/raw/x?key=•••&quot;</span>
              {"))()"}
            </code>
          </pre>
          <Link href="/scripts" className="mt-4 inline-flex text-[12px] text-brand-2 hover:underline">
            查看全部脚本 →
          </Link>
        </div>
      </div>

      <div className="border-t border-line/70">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-5 py-5 text-[12px] text-zinc-600 sm:flex-row sm:items-center sm:justify-between">
          <p>© {new Date().getFullYear()} loadbin · 仅用于学习与脚本分享，请遵守各平台服务条款。</p>
          <p className="font-mono text-[11px] text-zinc-600">built with next.js · drizzle · postgres</p>
        </div>
      </div>
    </footer>
  );
}
