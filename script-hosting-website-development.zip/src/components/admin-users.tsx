"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { cn } from "@/lib/format";

export type AdminUserRow = {
  id: number;
  username: string;
  role: string;
  createdAt: string;
  scriptCount: number;
};

export function AdminUsers({
  initialUsers,
  current,
  primaryAdmin,
}: {
  initialUsers: AdminUserRow[];
  current: string;
  primaryAdmin: string;
}) {
  const router = useRouter();
  const [users, setUsers] = useState(initialUsers);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [pending, setPending] = useState<string | null>(null);
  const [notice, setNotice] = useState<{ type: "ok" | "error"; text: string } | null>(null);

  async function refresh() {
    try {
      const response = await fetch("/api/admin/users", { cache: "no-store" });
      const data = (await response.json()) as { users?: AdminUserRow[] };
      if (data.users) setUsers(data.users);
      router.refresh();
    } catch {
      /* ignore */
    }
  }

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const name = username.trim().toLowerCase();
    if (!name) return;

    setPending("add");
    setNotice(null);
    try {
      const response = await fetch("/api/admin/users", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "promote", username: name, password: password.trim() || undefined }),
      });
      const data = (await response.json()) as {
        error?: string;
        user?: { username: string };
        created?: boolean;
        already?: boolean;
        tempPassword?: string;
      };
      if (!response.ok) throw new Error(data.error ?? "添加失败");

      setNotice({
        type: "ok",
        text: data.already
          ? `@${name} 已经是管理员了`
          : data.created
            ? `已创建管理员 @${name}，初始密码 ${data.tempPassword}，请提醒对方登录后自行修改`
            : `已将 @${name} 设为管理员`,
      });
      setUsername("");
      setPassword("");
      await refresh();
    } catch (cause) {
      setNotice({ type: "error", text: cause instanceof Error ? cause.message : "添加失败" });
    } finally {
      setPending(null);
    }
  }

  async function demote(name: string) {
    if (!window.confirm(`撤销 @${name} 的管理员权限？`)) return;
    setPending(name);
    setNotice(null);
    try {
      const response = await fetch("/api/admin/users", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "demote", username: name }),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "操作失败");
      setNotice({ type: "ok", text: `已撤销 @${name} 的管理员权限` });
      await refresh();
    } catch (cause) {
      setNotice({ type: "error", text: cause instanceof Error ? cause.message : "操作失败" });
    } finally {
      setPending(null);
    }
  }

  const admins = users.filter((user) => user.role === "admin");

  return (
    <div className="card overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-5 py-4">
        <div>
          <h2 className="text-[15px] font-semibold text-white">管理员</h2>
          <p className="mt-0.5 text-[11.5px] text-zinc-500">
            管理员可使用控制台开关脚本执行、停用/删除脚本。共 {admins.length} 位。
          </p>
        </div>
        <span className="chip !border-rose-500/25 !bg-rose-500/10 !text-rose-200">👑 admin</span>
      </div>

      <form onSubmit={submit} className="grid gap-2 border-b border-line px-5 py-3.5 sm:grid-cols-[1fr_1fr_auto]">
        <input
          value={username}
          onChange={(event) => setUsername(event.target.value.toLowerCase().replace(/[^a-z0-9_.-]/g, ""))}
          placeholder="用户名，例如 lqnb"
          className="field font-mono !text-[12px]"
          maxLength={24}
        />
        <input
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          type="password"
          placeholder="初始密码（可选，默认 loadbin-admin）"
          className="field font-mono !text-[12px]"
          maxLength={128}
        />
        <button type="submit" disabled={pending !== null || !username.trim()} className="btn btn-primary disabled:opacity-60">
          {pending === "add" ? "添加中…" : "设为管理员"}
        </button>
      </form>

      {notice && (
        <div
          className={cn(
            "border-b px-5 py-2.5 text-[12px]",
            notice.type === "ok"
              ? "border-lime/25 bg-lime/[0.06] text-lime-200"
              : "border-rose-500/25 bg-rose-500/[0.08] text-rose-300",
          )}
        >
          {notice.text}
        </div>
      )}

      <div className="divide-y divide-line/70">
        {users.map((user) => {
          const isAdmin = user.role === "admin";
          const isSelf = user.username === current;
          const isPrimary = user.username === primaryAdmin;
          return (
            <div key={user.id} className="flex flex-wrap items-center gap-3 px-5 py-2.5">
              <span
                className={cn(
                  "grid h-7 w-7 shrink-0 place-items-center rounded-md font-mono text-[11px] uppercase",
                  isAdmin ? "bg-rose-500/15 text-rose-200" : "bg-white/[0.05] text-zinc-400",
                )}
              >
                {user.username.slice(0, 1)}
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="truncate text-[12.5px] text-zinc-200">@{user.username}</span>
                  {isAdmin && (
                    <span className="chip !border-rose-500/25 !bg-rose-500/10 !text-rose-200">管理员</span>
                  )}
                  {isPrimary && <span className="chip !text-amber-300">主站长</span>}
                  {isSelf && <span className="chip !text-brand-2">你</span>}
                </div>
                <p className="font-mono text-[10.5px] text-zinc-600">
                  脚本 {user.scriptCount} · 加入 {new Date(user.createdAt).toLocaleDateString("zh-CN")}
                </p>
              </div>
              {isAdmin && !isSelf && !isPrimary && (
                <button
                  type="button"
                  onClick={() => void demote(user.username)}
                  disabled={pending !== null}
                  className="btn !py-1.5 !text-[11px] !border-line !bg-white/[0.03] !text-zinc-400 disabled:opacity-60"
                >
                  撤销管理员
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
