"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

export type HeaderUser = { id: number; username: string; role?: string };

export function UserMenu({ initialUser }: { initialUser: HeaderUser | null }) {
  const router = useRouter();
  const [loggedOut, setLoggedOut] = useState(false);
  const [open, setOpen] = useState(false);
  const [pending, setPending] = useState(false);

  const user = loggedOut ? null : initialUser;

  async function logout() {
    setPending(true);
    await fetch("/api/auth/logout", { method: "POST" }).catch(() => undefined);
    setLoggedOut(true);
    setOpen(false);
    setPending(false);
    router.push("/");
    router.refresh();
  }

  if (!user) {
    return (
      <div className="hidden items-center gap-1.5 sm:flex">
        <Link href="/login" className="btn btn-ghost !py-2 !text-[12.5px]">登录</Link>
        <Link href="/register" className="btn btn-primary !py-2 !text-[12.5px]">注册</Link>
      </div>
    );
  }

  return (
    <div className="relative hidden sm:block">
      <button
        type="button"
        onClick={() => setOpen((value) => !value)}
        className="flex items-center gap-2 rounded-lg border border-line bg-white/[0.03] px-2 py-1.5 text-[12.5px] text-zinc-200 transition hover:border-zinc-600"
      >
        <span className="grid h-6 w-6 place-items-center rounded-md bg-brand/25 font-mono text-[10px] uppercase text-brand-2">
          {user.username.slice(0, 1)}
        </span>
        <span className="max-w-[90px] truncate">{user.username}</span>
        <span className="text-[10px] text-zinc-500">▾</span>
      </button>

      {open && (
        <div className="absolute right-0 top-11 z-50 w-44 overflow-hidden rounded-xl border border-line bg-panel shadow-2xl">
          {user.role === "admin" && (
            <Link
              href="/account#owner"
              onClick={() => setOpen(false)}
              className="block bg-rose-500/10 px-3 py-2.5 text-[12.5px] font-medium text-rose-200 hover:bg-rose-500/20"
            >
              ⚙ 站长控制台（账户内）
            </Link>
          )}
          <Link
            href="/account"
            onClick={() => setOpen(false)}
            className="block px-3 py-2.5 text-[12.5px] text-zinc-300 hover:bg-white/[0.05] hover:text-white"
          >
            我的账号
          </Link>
          <Link
            href="/new"
            onClick={() => setOpen(false)}
            className="block px-3 py-2.5 text-[12.5px] text-zinc-300 hover:bg-white/[0.05] hover:text-white"
          >
            上传脚本
          </Link>
          <Link
            href="/manage"
            onClick={() => setOpen(false)}
            className="block px-3 py-2.5 text-[12.5px] text-zinc-300 hover:bg-white/[0.05] hover:text-white"
          >
            本地密钥托管
          </Link>
          <button
            type="button"
            onClick={logout}
            disabled={pending}
            className="block w-full border-t border-line px-3 py-2.5 text-left text-[12.5px] text-rose-300 hover:bg-rose-500/10 disabled:opacity-60"
          >
            {pending ? "退出中…" : "退出登录"}
          </button>
        </div>
      )}
    </div>
  );
}
