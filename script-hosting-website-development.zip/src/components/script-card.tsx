import Link from "next/link";
import type { ScriptListItem } from "@/lib/queries";
import { formatNumber, initialOf, timeAgo } from "@/lib/format";

export function ScriptCard({ script }: { script: ScriptListItem }) {
  return (
    <Link
      href={`/s/${script.slug}`}
      className="card card-hover group flex flex-col p-5 focus:outline-none focus-visible:ring-2 focus-visible:ring-brand/70"
    >
      <div className="flex items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-1.5">
          {script.tags.slice(0, 2).map((tag) => (
            <span key={tag} className="chip">
              {tag}
            </span>
          ))}
        </div>
        <span className="font-mono text-[10px] uppercase tracking-wider text-zinc-600">
          {script.language}
        </span>
      </div>

      <h3 className="mt-4 text-[15px] font-semibold leading-snug text-white transition-colors group-hover:text-brand-2">
        {script.title}
      </h3>
      <p className="mt-2 line-clamp-2 text-[13px] leading-relaxed text-zinc-500">
        {script.description || "作者还没有填写描述。"}
      </p>

      <div className="mt-auto flex items-center gap-3 pt-5 text-[11.5px] text-zinc-500">
        <span className="flex items-center gap-1.5">
          <span className="grid h-5 w-5 place-items-center rounded-full bg-brand/20 font-mono text-[9px] text-brand-2">
            {initialOf(script.authorName)}
          </span>
          {script.authorName}
        </span>
        <span className="text-zinc-700">·</span>
        <span className="font-mono">👁 {formatNumber(script.views)}</span>
        <span className="font-mono">♥ {formatNumber(script.likes)}</span>
        <span className="ml-auto text-zinc-600">{timeAgo(script.updatedAt)}</span>
      </div>
    </Link>
  );
}
