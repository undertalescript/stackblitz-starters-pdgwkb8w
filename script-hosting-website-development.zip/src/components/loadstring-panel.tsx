"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { cn } from "@/lib/format";
import { CopyButton } from "@/components/copy-button";

type Variant = "stable" | "classic" | "async" | "request" | "luau";

const TABS: { key: Variant; label: string; hint: string }[] = [
  {
    key: "stable",
    label: "稳定版（推荐）",
    hint: "带错误捕获，任何失败都会在控制台打印中文原因，不会抛出 HTTP 报错",
  },
  {
    key: "classic",
    label: "经典 loadstring",
    hint: "最短写法，适合确定能正常访问的执行器",
  },
  {
    key: "async",
    label: "HttpGetAsync",
    hint: "异步请求版本，适合阻塞式执行器",
  },
  {
    key: "request",
    label: "request 库",
    hint: "使用 request 并附带 Roblox UA，部分执行器更稳定",
  },
  {
    key: "luau",
    label: "源码 + 语法检查",
    hint: "先取源码再 loadstring，语法错误会定位到具体行",
  },
];

export function LoadstringPanel({
  slug,
  baseUrl,
  accessToken,
}: {
  slug: string;
  baseUrl: string;
  accessToken: string;
}) {
  const [variant, setVariant] = useState<Variant>("stable");
  const [showUrl, setShowUrl] = useState(true);

  const rawUrl = `${baseUrl}/api/raw/${slug}?key=${accessToken}`;
  const pathUrl = `${baseUrl}/k/${accessToken}/${slug}`;

  const snippet = useMemo(() => {
    switch (variant) {
      case "classic":
        return `loadstring(game:HttpGet("${rawUrl}"))()`;
      case "async":
        return `loadstring(game:HttpGetAsync("${rawUrl}"))()`;
      case "request":
        return `local ok, res = pcall(function()\n    return request({\n        Url = "${rawUrl}",\n        Method = "GET",\n        Headers = { ["User-Agent"] = "Roblox/WinInet" },\n    })\nend)\n\nif not ok or not res or not res.Body then\n    return warn("[loadbin] 请求失败: " .. tostring(res))\nend\n\nloadstring(res.Body)()`;
      case "luau":
        return `local source = game:HttpGet("${rawUrl}")\nlocal chunk, err = loadstring(source)\n\nif not chunk then\n    return warn("[loadbin] 语法错误: " .. tostring(err))\nend\n\nchunk()`;
      default:
        return `local ok, source = pcall(function()\n    return game:HttpGet("${rawUrl}")\nend)\n\nif not ok or not source then\n    return warn("[loadbin] 加载失败: " .. tostring(source))\nend\n\nlocal chunk, err = loadstring(source)\nif not chunk then\n    return warn("[loadbin] 语法错误: " .. tostring(err))\nend\n\nchunk()`;
    }
  }, [rawUrl, variant]);

  const activeHint = TABS.find((tab) => tab.key === variant)?.hint ?? "";

  return (
    <div className="overflow-hidden rounded-xl border border-line bg-[#080910]">
      <div className="flex flex-wrap items-center gap-1 border-b border-line/80 px-2.5 py-2">
        <span className="mr-1 hidden items-center gap-1.5 px-1.5 font-mono text-[10px] uppercase tracking-wider text-zinc-500 sm:flex">
          <span className="h-1.5 w-1.5 rounded-full bg-lime" />
          执行
        </span>
        {TABS.map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setVariant(tab.key)}
            className={cn(
              "rounded-md px-2.5 py-1 text-[11.5px] transition-colors",
              variant === tab.key
                ? "bg-brand/15 text-brand-2 ring-1 ring-brand/40"
                : "text-zinc-500 hover:bg-white/5 hover:text-zinc-300",
            )}
          >
            {tab.label}
          </button>
        ))}
        <CopyButton
          value={snippet}
          label="复制 loadstring"
          copiedLabel="已复制到剪贴板"
          variant="lime"
          className="ml-auto !py-1.5"
        />
      </div>

      <div className="flex flex-wrap items-center gap-1.5 border-b border-line/60 bg-white/[0.015] px-4 py-1.5">
        <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-lime" />
        <p className="text-[11px] leading-relaxed text-zinc-500">{activeHint}</p>
        <span className="ml-auto shrink-0 rounded border border-lime/25 bg-lime/10 px-1.5 py-0.5 font-mono text-[9.5px] uppercase tracking-wider text-lime-300">
          source protected
        </span>
      </div>

      <pre className="code-scroll max-h-[22rem] overflow-auto px-4 py-4 font-mono text-[12.5px] leading-relaxed text-zinc-300">
        <code>{snippet}</code>
      </pre>

      <div className="border-t border-line/80 bg-white/[0.015] px-3 py-2.5">
        <div className="flex items-center gap-2">
          <span className="flex shrink-0 items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-zinc-500">
            🔒 签名直链
          </span>
          <code className="min-w-0 flex-1 truncate font-mono text-[11px] text-zinc-500">
            {showUrl ? rawUrl : `${baseUrl}/api/raw/${slug}?key=••••••••`}
          </code>
          <button
            type="button"
            onClick={() => setShowUrl((value) => !value)}
            className="btn btn-ghost !py-1 !text-[10.5px]"
          >
            {showUrl ? "隐藏" : "显示"}
          </button>
          <CopyButton value={rawUrl} label="复制直链" className="!py-1 !text-[10.5px]" />
        </div>
        <div className="mt-1.5 flex items-center gap-2">
          <span className="flex shrink-0 items-center gap-1.5 font-mono text-[10px] uppercase tracking-wider text-zinc-500">
            🛡 路径直链
          </span>
          <code className="min-w-0 flex-1 truncate font-mono text-[11px] text-zinc-500">{pathUrl}</code>
          <CopyButton value={pathUrl} label="复制" className="!py-1 !text-[10.5px]" />
        </div>
      </div>

      <div className="flex items-start gap-1.5 border-t border-line/80 px-4 py-2.5">
        <span className="mt-0.5 text-[11px] text-amber-300">⚠</span>
        <p className="text-[11px] leading-relaxed text-zinc-500">
          必须复制<b className="text-zinc-300">整段 loadstring</b>（内含 <code className="font-mono text-lime-300">?key=</code> 签名），
          只复制裸链接会收到「缺少访问签名」提示。浏览器直接打开直链仍会被 403 拒绝，
          但执行器（Delta / Ninja / Solara / Wave 等）可以正常读取。raw 返回的是 Shield v3 两段式引导器：**文件本身不含载荷**，加密数据在运行时限时取回并校验，
          静态分析拿不到任何可解码内容。
          <Link href="/docs#troubleshoot" className="ml-1 text-brand-2/80 hover:text-brand-2">执行报错？</Link>
        </p>
      </div>
    </div>
  );
}
