"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

export function AuthForm({ mode, next }: { mode: "login" | "register"; next?: string }) {
  const router = useRouter();
  const isRegister = mode === "register";
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);

    if (isRegister && password !== confirm) {
      setError("两次输入的密码不一致");
      return;
    }

    setPending(true);
    try {
      const response = await fetch(`/api/auth/${isRegister ? "register" : "login"}`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ username, password }),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "操作失败");
      router.push(next || "/account");
      router.refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "操作失败");
      setPending(false);
    }
  }

  return (
    <form onSubmit={submit} className="card mx-auto w-full max-w-sm p-6">
      <div className="flex items-center gap-2">
        <span className="grid h-9 w-9 place-items-center rounded-lg bg-gradient-to-br from-brand to-[#4c1d95] font-mono text-[12px] font-bold text-white">
          {"{ }"}
        </span>
        <div>
          <h1 className="text-[15px] font-semibold text-white">{isRegister ? "创建账号" : "登录 loadbin"}</h1>
          <p className="text-[11.5px] text-zinc-500">
            {isRegister ? "注册后即可托管并保护你的脚本源码" : "登录以管理你的脚本与源码保护设置"}
          </p>
        </div>
      </div>

      <div className="mt-5 space-y-3">
        <div>
          <label className="label" htmlFor="username">用户名</label>
          <input
            id="username"
            value={username}
            onChange={(event) => setUsername(event.target.value)}
            autoComplete="username"
            required
            minLength={3}
            maxLength={24}
            placeholder="小写字母、数字、下划线"
            className="field font-mono !text-[12.5px]"
          />
        </div>
        <div>
          <label className="label" htmlFor="password">密码</label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            autoComplete={isRegister ? "new-password" : "current-password"}
            required
            minLength={6}
            maxLength={128}
            placeholder="至少 6 位"
            className="field font-mono !text-[12.5px]"
          />
        </div>
        {isRegister && (
          <div>
            <label className="label" htmlFor="confirm">确认密码</label>
            <input
              id="confirm"
              type="password"
              value={confirm}
              onChange={(event) => setConfirm(event.target.value)}
              autoComplete="new-password"
              required
              minLength={6}
              placeholder="再次输入密码"
              className="field font-mono !text-[12.5px]"
            />
          </div>
        )}
      </div>

      {error && (
        <p className="mt-3 rounded-lg border border-rose-500/30 bg-rose-500/[0.08] px-3 py-2 text-[12px] text-rose-300">
          {error}
        </p>
      )}

      <button type="submit" disabled={pending} className="btn btn-primary mt-4 w-full disabled:opacity-60">
        {pending ? "处理中…" : isRegister ? "注册并登录" : "登录"}
      </button>

      <p className="mt-4 text-center text-[12px] text-zinc-500">
        {isRegister ? "已经有账号？" : "还没有账号？"}{" "}
        <Link href={isRegister ? "/login" : "/register"} className="text-brand-2 hover:underline">
          {isRegister ? "去登录" : "免费注册"}
        </Link>
      </p>

      <p className="mt-3 rounded-lg border border-line bg-white/[0.015] px-3 py-2 text-[11px] leading-relaxed text-zinc-600">
        密码使用 scrypt 加盐哈希存储，会话保存在 HttpOnly Cookie 中，服务器不保留明文密码。
      </p>
    </form>
  );
}
