"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { cn, formatNumber } from "@/lib/format";

export type AdminSettings = {
  scriptsEnabled: boolean;
  maintenanceMode: boolean;
  announcement: string;
  updatedAt: string | null;
  updatedBy: string | null;
};

export type AdminScript = {
  slug: string;
  title: string;
  authorName: string;
  ownerName: string | null;
  visibility: string;
  disabled: boolean;
  obfuscation?: string;
  inflation?: number;
  codeLength: number;
  views: number;
  runs: number;
  likes: number;
};

export function AdminClient({
  initialSettings,
  initialScripts,
}: {
  initialSettings: AdminSettings;
  initialScripts: AdminScript[];
}) {
  const router = useRouter();
  const [settings, setSettings] = useState(initialSettings);
  const [scripts, setScripts] = useState(initialScripts);
  const [announcement, setAnnouncement] = useState(initialSettings.announcement);
  const [pending, setPending] = useState<string | null>(null);
  const [notice, setNotice] = useState<{ type: "ok" | "error"; text: string } | null>(null);

  async function patchSettings(patch: Partial<AdminSettings>, label: string) {
    setPending(label);
    setNotice(null);

    const previous = settings;
    setSettings((current) => ({ ...current, ...patch }));

    try {
      const response = await fetch("/api/admin/settings", {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(patch),
      });
      const data = (await response.json()) as { settings?: AdminSettings; error?: string };
      if (!response.ok || !data.settings) throw new Error(data.error ?? "保存失败");
      setSettings(data.settings);
      setAnnouncement(data.settings.announcement);
      setNotice({ type: "ok", text: label === "announcement" ? "公告已保存" : "设置已生效" });
      router.refresh();
    } catch (cause) {
      setSettings(previous);
      setNotice({ type: "error", text: cause instanceof Error ? cause.message : "保存失败" });
    } finally {
      setPending(null);
    }
  }

  async function toggleScript(slug: string, disabled: boolean) {
    setPending(slug);
    setNotice(null);
    setScripts((current) => current.map((item) => (item.slug === slug ? { ...item, disabled } : item)));
    try {
      const response = await fetch(`/api/admin/scripts/${slug}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ disabled }),
      });
      if (!response.ok) {
        const data = (await response.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? "操作失败");
      }
      setNotice({ type: "ok", text: disabled ? "该脚本已被停用" : "该脚本已恢复执行" });
      router.refresh();
    } catch (cause) {
      setScripts((current) => current.map((item) => (item.slug === slug ? { ...item, disabled: !disabled } : item)));
      setNotice({ type: "error", text: cause instanceof Error ? cause.message : "操作失败" });
    } finally {
      setPending(null);
    }
  }

  async function deleteScript(slug: string, title: string) {
    if (!window.confirm(`删除「${title}」？所有 loadstring 链接都会立即失效。`)) return;
    setPending(slug);
    setNotice(null);
    try {
      const response = await fetch(`/api/admin/scripts/${slug}`, { method: "DELETE" });
      if (!response.ok && response.status !== 404) throw new Error("删除失败");
      setScripts((current) => current.filter((item) => item.slug !== slug));
      setNotice({ type: "ok", text: "脚本已删除" });
      router.refresh();
    } catch (cause) {
      setNotice({ type: "error", text: cause instanceof Error ? cause.message : "删除失败" });
    } finally {
      setPending(null);
    }
  }

  return (
    <div className="space-y-5">
      {notice && (
        <div
          className={cn(
            "rounded-xl border px-4 py-3 text-[12.5px]",
            notice.type === "ok"
              ? "border-lime/30 bg-lime/[0.07] text-lime-200"
              : "border-rose-500/30 bg-rose-500/[0.08] text-rose-300",
          )}
        >
          {notice.text}
        </div>
      )}

      {/* Kill switch */}
      <div
        className={cn(
          "card overflow-hidden border-2",
          settings.scriptsEnabled ? "border-line" : "border-rose-500/50",
        )}
      >
        <div className="flex flex-wrap items-start justify-between gap-4 p-5">
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span
                className={cn(
                  "h-2 w-2 rounded-full",
                  settings.scriptsEnabled
                    ? "bg-lime shadow-[0_0_10px_#c8f75a]"
                    : "bg-rose-400 shadow-[0_0_10px_#fb7185]",
                )}
              />
              <h2 className="text-[15px] font-semibold text-white">全站脚本执行开关</h2>
              <span
                className={cn(
                  "chip",
                  settings.scriptsEnabled
                    ? "!border-lime/30 !bg-lime/10 !text-lime-300"
                    : "!border-rose-500/30 !bg-rose-500/10 !text-rose-300",
                )}
              >
                {settings.scriptsEnabled ? "运行中" : "已停止"}
              </span>
            </div>
            <p className="mt-2 max-w-xl text-[12.5px] leading-relaxed text-zinc-500">
              关闭后，<b className="text-zinc-300">所有</b> loadstring / HttpGet 请求都会返回{" "}
              <code className="font-mono text-rose-300">503</code> 与 Lua <code className="font-mono">warn</code> 提示，
              任何脚本都无法执行；脚本页仍可浏览，执行次数不再增长。
            </p>
          </div>
          <button
            type="button"
            onClick={() => {
              if (
                settings.scriptsEnabled &&
                !window.confirm("确认停止全站脚本执行？所有用户将无法运行任何脚本。")
              ) {
                return;
              }
              void patchSettings({ scriptsEnabled: !settings.scriptsEnabled }, "scripts");
            }}
            disabled={pending !== null}
            className={cn(
              "btn shrink-0 !px-5 !py-3 disabled:opacity-60",
              settings.scriptsEnabled
                ? "!border-rose-500/50 !bg-rose-500/15 !text-rose-200"
                : "btn-lime",
            )}
          >
            {pending === "scripts"
              ? "处理中…"
              : settings.scriptsEnabled
                ? "■ 立即停止脚本执行"
                : "▶ 恢复脚本执行"}
          </button>
        </div>
      </div>

      {/* Maintenance + announcement */}
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="card p-5">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h2 className="text-[14px] font-semibold text-white">维护模式</h2>
              <p className="mt-1 text-[11.5px] leading-relaxed text-zinc-500">
                开启后除登录与后台外，全站显示维护页。
              </p>
            </div>
            <button
              type="button"
              role="switch"
              aria-checked={settings.maintenanceMode}
              onClick={() => void patchSettings({ maintenanceMode: !settings.maintenanceMode }, "maintenance")}
              disabled={pending !== null}
              className={cn(
                "relative h-6 w-11 shrink-0 rounded-full border transition-colors",
                settings.maintenanceMode ? "border-amber-400/60 bg-amber-400/30" : "border-line bg-white/[0.06]",
              )}
            >
              <span
                className={cn(
                  "absolute top-0.5 h-4.5 w-4.5 rounded-full bg-white transition-all",
                  settings.maintenanceMode ? "left-[22px]" : "left-0.5",
                )}
                style={{ height: 18, width: 18 }}
              />
            </button>
          </div>
          <p className="mt-4 font-mono text-[10.5px] text-zinc-600">
            {settings.updatedBy ? `最近修改：${settings.updatedBy}` : "尚未修改"}
          </p>
        </div>

        <div className="card p-5">
          <h2 className="text-[14px] font-semibold text-white">全站公告</h2>
          <p className="mt-1 text-[11.5px] text-zinc-500">显示在页面顶部的横幅，留空即关闭。</p>
          <textarea
            value={announcement}
            onChange={(event) => setAnnouncement(event.target.value)}
            rows={2}
            maxLength={280}
            placeholder="例如：今晚 23:00 维护，脚本执行将暂停 30 分钟。"
            className="field mt-3 resize-y !text-[12.5px]"
          />
          <button
            type="button"
            onClick={() => void patchSettings({ announcement }, "announcement")}
            disabled={pending !== null}
            className="btn btn-ghost mt-2 !py-1.5 !text-[11.5px] disabled:opacity-60"
          >
            {pending === "announcement" ? "保存中…" : "保存公告"}
          </button>
        </div>
      </div>

      {/* Script moderation */}
      <div className="card overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-5 py-4">
          <div>
            <h2 className="text-[15px] font-semibold text-white">脚本管理</h2>
            <p className="mt-0.5 text-[11.5px] text-zinc-500">
              共 {scripts.length} 个 · 可停用单个脚本或直接删除
            </p>
          </div>
          <Link href="/scripts" className="btn btn-ghost !py-1.5 !text-[11.5px]">查看前台</Link>
        </div>

        <div className="divide-y divide-line/70">
          {scripts.map((script) => (
            <div key={script.slug} className="flex flex-wrap items-center gap-3 px-5 py-3">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <Link href={`/s/${script.slug}`} className="truncate text-[13px] text-zinc-200 hover:text-brand-2">
                    {script.title}
                  </Link>
                  {script.disabled && (
                    <span className="chip !border-rose-500/30 !bg-rose-500/10 !text-rose-300">已停用</span>
                  )}
                  {script.ownerName && <span className="chip !text-brand-2">@{script.ownerName}</span>}
                </div>
                <p className="mt-0.5 truncate font-mono text-[10.5px] text-zinc-600">
                  /{script.slug} · {(script.codeLength / 1024).toFixed(1)}KB · 👁 {formatNumber(script.views)} · ▶{" "}
                  {formatNumber(script.runs)} · ♥ {formatNumber(script.likes)}
                </p>
              </div>
              <div className="flex shrink-0 items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => void toggleScript(script.slug, !script.disabled)}
                  disabled={pending !== null}
                  className={cn(
                    "btn !py-1.5 !text-[11px] disabled:opacity-60",
                    script.disabled ? "btn-ghost" : "!border-amber-400/30 !bg-amber-400/10 !text-amber-200",
                  )}
                >
                  {script.disabled ? "恢复" : "停用"}
                </button>
                <button
                  type="button"
                  onClick={() => void deleteScript(script.slug, script.title)}
                  disabled={pending !== null}
                  className="btn !py-1.5 !text-[11px] !border-rose-500/30 !bg-rose-500/10 !text-rose-300 disabled:opacity-60"
                >
                  删除
                </button>
              </div>
            </div>
          ))}
          {scripts.length === 0 && (
            <p className="px-5 py-10 text-center text-[12.5px] text-zinc-500">还没有脚本。</p>
          )}
        </div>
      </div>
    </div>
  );
}
