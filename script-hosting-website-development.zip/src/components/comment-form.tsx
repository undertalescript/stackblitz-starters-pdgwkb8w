"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function CommentForm({ slug }: { slug: string }) {
  const router = useRouter();
  const [authorName, setAuthorName] = useState("");
  const [body, setBody] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setError(null);

    try {
      const response = await fetch(`/api/scripts/${slug}/comments`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ authorName: authorName.trim() || "匿名", body: body.trim() }),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "评论失败");
      setBody("");
      router.refresh();
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "评论失败");
    } finally {
      setPending(false);
    }
  }

  return (
    <form onSubmit={submit} className="rounded-xl border border-line bg-panel/60 p-4">
      <div className="grid gap-3 sm:grid-cols-[200px_1fr]">
        <input
          value={authorName}
          onChange={(event) => setAuthorName(event.target.value)}
          maxLength={40}
          placeholder="昵称（可选）"
          className="field"
        />
        <input
          value={body}
          onChange={(event) => setBody(event.target.value)}
          maxLength={500}
          required
          minLength={2}
          placeholder="说点什么，比如脚本能不能正常运行…"
          className="field"
        />
      </div>
      <div className="mt-3 flex items-center justify-between gap-3">
        <p className="text-[11px] text-zinc-600">{body.length}/500 · 请友善交流，禁止发布违规内容</p>
        <button type="submit" disabled={pending || body.trim().length < 2} className="btn btn-primary !py-2 disabled:opacity-50">
          {pending ? "发送中…" : "发布评论"}
        </button>
      </div>
      {error && <p className="mt-2 text-[12px] text-rose-400">{error}</p>}
    </form>
  );
}
