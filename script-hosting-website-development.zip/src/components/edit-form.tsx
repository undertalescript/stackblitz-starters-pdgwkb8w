"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { CodeView } from "@/components/code-view";
import { cn, parseTags } from "@/lib/format";
import { rememberScript } from "@/lib/local-store";

export type EditableScript = {
  slug: string;
  title: string;
  description: string;
  authorName: string;
  tags: string[];
  code: string;
  visibility: string;
  obfuscation: string;
  inflation: number;
};

export function EditForm({
  initial,
  editKey,
  isOwner = false,
  baseUrl,
}: {
  initial: EditableScript;
  editKey?: string;
  isOwner?: boolean;
  baseUrl: string;
}) {
  const router = useRouter();
  const [values, setValues] = useState(initial);
  const [tagInput, setTagInput] = useState(initial.tags.join(", "));
  const tags = useMemo(() => parseTags(tagInput), [tagInput]);
  const [pending, setPending] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [message, setMessage] = useState<{ type: "ok" | "error"; text: string } | null>(null);

  function update<K extends keyof EditableScript>(key: K, value: EditableScript[K]) {
    setValues((current) => ({ ...current, [key]: value }));
  }

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setPending(true);
    setMessage(null);

    try {
      const response = await fetch(`/api/scripts/${initial.slug}`, {
        method: "PATCH",
        headers: {
          "content-type": "application/json",
          ...(editKey ? { "x-edit-key": editKey } : {}),
        },
        body: JSON.stringify({
          title: values.title.trim(),
          description: values.description.trim(),
          authorName: values.authorName.trim() || "匿名",
          tags,
          code: values.code,
          visibility: values.visibility,
          obfuscation: values.obfuscation,
          inflation: values.inflation,
        }),
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "保存失败，请检查编辑密钥");
      if (editKey) rememberScript({ slug: initial.slug, title: values.title.trim(), editKey });
      setMessage({ type: "ok", text: "已保存，loadstring 链接保持不变。" });
      router.refresh();
    } catch (cause) {
      setMessage({ type: "error", text: cause instanceof Error ? cause.message : "保存失败" });
    } finally {
      setPending(false);
    }
  }

  async function destroy() {
    setDeleting(true);
    setMessage(null);

    try {
      const response = await fetch(`/api/scripts/${initial.slug}`, {
        method: "DELETE",
        headers: editKey ? { "x-edit-key": editKey } : {},
      });
      const data = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(data.error ?? "删除失败");
      router.push(isOwner ? "/account" : "/manage");
    } catch (cause) {
      setMessage({ type: "error", text: cause instanceof Error ? cause.message : "删除失败" });
      setDeleting(false);
    }
  }

  return (
    <form onSubmit={save} className="grid gap-6 lg:grid-cols-[1fr_340px]">
      <div className="space-y-5">
        <div className="card space-y-4 p-5">
          <div>
            <label className="label" htmlFor="edit-title">标题</label>
            <input
              id="edit-title"
              value={values.title}
              onChange={(event) => update("title", event.target.value)}
              maxLength={120}
              required
              className="field"
            />
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="edit-author">作者署名</label>
              <input
                id="edit-author"
                value={values.authorName}
                onChange={(event) => update("authorName", event.target.value)}
                maxLength={40}
                className="field"
              />
            </div>
            <div>
              <label className="label" htmlFor="edit-visibility">可见性</label>
              <select
                id="edit-visibility"
                value={values.visibility}
                onChange={(event) => update("visibility", event.target.value)}
                className="field"
              >
                <option value="public">公开 · 出现在列表</option>
                <option value="unlisted">不公开 · 仅链接可访问</option>
              </select>
            </div>
          </div>
          <div>
            <label className="label" htmlFor="edit-description">简介</label>
            <textarea
              id="edit-description"
              value={values.description}
              onChange={(event) => update("description", event.target.value)}
              rows={3}
              maxLength={500}
              className="field resize-y"
            />
          </div>
          <div>
            <label className="label" htmlFor="edit-obfuscation">源码混淆（影响 raw 接口输出）</label>
            <select
              id="edit-obfuscation"
              value={values.obfuscation}
              onChange={(event) => update("obfuscation", event.target.value)}
              className="field"
            >
              <option value="ultra">极限（Shield v3）· 状态机 VM + 加密字符串表 + 多层包裹</option>
              <option value="strong">强 · 状态机 VM + 加密字符串表</option>
              <option value="light">轻量 · 状态机 VM，体积较小</option>
              <option value="none">不混淆 · 返回原始源码</option>
            </select>
            <p className="mt-1 text-[11px] text-zinc-600">原始源码始终只有你（作者）可以看到。</p>
          </div>
          <div>
            <label className="label" htmlFor="edit-inflation">动态膨胀等级</label>
            <select
              id="edit-inflation"
              value={values.inflation}
              onChange={(event) => update("inflation", Number(event.target.value))}
              className="field"
            >
              <option value={0}>关闭 · 加载器最精简</option>
              <option value={1}>标准 · 填充表 + 掩码层</option>
              <option value={2}>加强（推荐）· 填充表参与解密 + 诱饵函数</option>
              <option value={3}>重度 · 更大填充与更多诱饵，启动略慢</option>
            </select>
          </div>
          <div>
            <label className="label" htmlFor="edit-tags">标签</label>
            <input
              id="edit-tags"
              value={tagInput}
              onChange={(event) => setTagInput(event.target.value)}
              placeholder="通用, 自动, 工具"
              className="field"
            />
          </div>
        </div>

        <div className="card p-5">
          <div className="mb-3 flex items-center justify-between">
            <label className="label !mb-0" htmlFor="edit-code">脚本代码</label>
            <span className="chip">{values.code.split("\n").length} 行</span>
          </div>
          <textarea
            id="edit-code"
            value={values.code}
            onChange={(event) => update("code", event.target.value)}
            required
            spellCheck={false}
            className="field min-h-[380px] resize-y font-mono !text-[12.5px] leading-[1.7]"
          />
        </div>

        {message && (
          <div
            className={cn(
              "rounded-xl border px-4 py-3 text-[12.5px]",
              message.type === "ok"
                ? "border-lime/30 bg-lime/[0.07] text-lime-200"
                : "border-rose-500/30 bg-rose-500/[0.08] text-rose-300",
            )}
          >
            {message.text}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <button type="submit" disabled={pending} className="btn btn-primary !px-5 disabled:opacity-60">
            {pending ? "保存中…" : "保存修改"}
          </button>
          <Link href={`/s/${initial.slug}`} className="btn btn-ghost">返回脚本页</Link>
          <button
            type="button"
            onClick={() => setConfirmDelete(true)}
            className="ml-auto text-[12.5px] text-rose-400 hover:text-rose-300"
          >
            删除脚本
          </button>
        </div>

        {confirmDelete && (
          <div className="rounded-xl border border-rose-500/30 bg-rose-500/[0.06] p-4">
            <p className="text-[12.5px] text-rose-200">
              删除后 <code className="font-mono">/api/raw/{initial.slug}</code> 将立即失效，且不可恢复。
            </p>
            <div className="mt-3 flex gap-2">
              <button
                type="button"
                onClick={destroy}
                disabled={deleting}
                className="btn !border-rose-500/50 !bg-rose-500/20 !text-rose-100 disabled:opacity-60"
              >
                {deleting ? "删除中…" : "确认删除"}
              </button>
              <button type="button" onClick={() => setConfirmDelete(false)} className="btn btn-ghost">
                取消
              </button>
            </div>
          </div>
        )}
      </div>

      <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
        <div className="card p-4">
          <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-zinc-500">实时预览</p>
          <div className="mt-3">
            <CodeView code={values.code || "-- 暂无代码"} maxHeight="22rem" className="!rounded-lg" />
          </div>
        </div>
        <div className="card p-4">
          <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-zinc-500">接口地址</p>
          <code className="mt-2 block break-all rounded-lg border border-line bg-[#080910] px-3 py-2 font-mono text-[11.5px] text-zinc-400">
            {baseUrl}/api/raw/{initial.slug}?key=•••·
          </code>
          <p className="mt-2 text-[11px] text-zinc-600">
            短链不可修改，保证已发布的 loadstring 永久有效；代码内容实时更新。直链必须带签名，
            浏览器直接打开会被拒绝。
          </p>
        </div>
      </aside>
    </form>
  );
}
