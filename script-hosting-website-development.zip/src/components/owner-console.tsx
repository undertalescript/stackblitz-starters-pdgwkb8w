import Link from "next/link";
import { AdminClient, type AdminScript, type AdminSettings } from "@/components/admin-client";
import { AdminUsers, type AdminUserRow } from "@/components/admin-users";
import { formatNumber } from "@/lib/format";
import { asc } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { sql } from "drizzle-orm";
import { getAllScriptsForAdmin, getPlatformStats } from "@/lib/queries";
import { getSiteSettings } from "@/lib/settings";

/**
 * Owner control panel. Rendered straight inside /account for admin users
 * so there is no separate page to hunt for.
 */
export async function OwnerConsole({ username }: { username: string }) {
  const [settings, scripts, stats, members] = await Promise.all([
    getSiteSettings(),
    getAllScriptsForAdmin(80),
    getPlatformStats(),
    db
      .select({
        id: users.id,
        username: users.username,
        role: users.role,
        createdAt: users.createdAt,
        scriptCount: sql<number>`(
          select count(*)::int from scripts where scripts.owner_id = ${users.id}
        )`,
      })
      .from(users)
      .orderBy(asc(users.id)),
  ]);

  const adminRows: AdminUserRow[] = members.map((member) => ({
    id: member.id,
    username: member.username,
    role: member.role,
    createdAt: member.createdAt.toISOString(),
    scriptCount: member.scriptCount,
  }));

  const adminSettings: AdminSettings = {
    scriptsEnabled: settings.scriptsEnabled,
    maintenanceMode: settings.maintenanceMode,
    announcement: settings.announcement,
    updatedAt: settings.updatedAt ? settings.updatedAt.toISOString() : null,
    updatedBy: settings.updatedBy,
  };

  const adminScripts: AdminScript[] = scripts.map((script) => ({
    slug: script.slug,
    title: script.title,
    authorName: script.authorName,
    ownerName: script.ownerName,
    visibility: script.visibility,
    disabled: script.disabled,
    codeLength: script.codeLength,
    views: script.views,
    runs: script.runs,
    likes: script.likes,
  }));

  return (
    <section id="owner" className="scroll-mt-24">
      <div className="card overflow-hidden border-rose-500/30">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-rose-500/20 bg-rose-500/[0.07] px-5 py-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-[15px]">👑</span>
              <h2 className="text-[16px] font-semibold text-white">站长控制台</h2>
              <span className="chip !border-rose-500/30 !bg-rose-500/10 !text-rose-300">owner only</span>
            </div>
            <p className="mt-1 text-[12px] leading-relaxed text-zinc-400">
              @{username}，你可以在这里一键关闭全站脚本执行、停用或删除任意脚本。无需前往其他页面。
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <span
              className={`chip ${
                settings.scriptsEnabled
                  ? "!border-lime/30 !bg-lime/10 !text-lime-300"
                  : "!border-rose-500/30 !bg-rose-500/10 !text-rose-300"
              }`}
            >
              脚本执行：{settings.scriptsEnabled ? "开启" : "已关闭"}
            </span>
            <span className="chip">维护：{settings.maintenanceMode ? "开" : "关"}</span>
            <span className="chip">脚本 {formatNumber(stats.scripts)}</span>
            <span className="chip">执行 {formatNumber(stats.runs)}</span>
          </div>
        </div>

        <div className="space-y-4 p-5">
          <AdminClient initialSettings={adminSettings} initialScripts={adminScripts} />
          <AdminUsers
            initialUsers={adminRows}
            current={username}
            primaryAdmin={(process.env.ADMIN_USERNAME ?? "zasqw89071").toLowerCase()}
          />
        </div>
      </div>

      <p className="mt-2.5 text-right font-mono text-[10.5px] text-zinc-600">
        直达链接：<Link href="/account#owner" className="text-brand-2/80 hover:text-brand-2">/account#owner</Link>{" "}
        · 接口：<span className="text-zinc-500">PATCH /api/admin/settings</span>
      </p>
    </section>
  );
}
