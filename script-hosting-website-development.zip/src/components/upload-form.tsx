"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { CodeView } from "@/components/code-view";
import { CopyButton } from "@/components/copy-button";
import { rememberScript } from "@/lib/local-store";
import { cn, parseTags } from "@/lib/format";

const TEMPLATE = `-- 在这里编写你的 Luau 脚本
local Players = game:GetService("Players")
local player = Players.LocalPlayer

local function main()
    print("[loadbin] hello from " .. tostring(player))
end

main()`;

const OBFUSCATION_OPTIONS = [
  { value: "ultra", label: "极限（Shield v3）", hint: "状态机 VM + 加密字符串表 + 多层包裹" },
  { value: "strong", label: "强", hint: "状态机 VM + 加密字符串表" },
  { value: "light", label: "轻量", hint: "状态机 VM，体积较小" },
  { value: "none", label: "不混淆", hint: "返回原始源码" },
] as const;

const INFLATION_OPTIONS = [
  { value: 0, label: "关闭", hint: "最精简" },
  { value: 1, label: "标准", hint: "填充表 + 掩码层" },
  { value: 2, label: "加强", hint: "推荐 · 诱饵函数" },
  { value: 3, label: "重度", hint: "启动略慢" },
] as const;

const TAG_SUGGESTIONS = ["通用", "自动", "工具", "透视", "战斗", "模拟器", "Blox Fruits", "UI", "库"];

type CreateResult = {
  slug: string;
  title: string;
  editKey: string;
  pageUrl: string;
  rawUrl: string;
  loadstring: string;
};

export function UploadForm({ baseUrl }: { baseUrl: string }) {
  const [title, setTitle] = useState("");
  const [authorName, setAuthorName] = useState("");
  const [description, setDescription] = useState("");
  const [tagInput, setTagInput] = useState("");
  const [visibility, setVisibility] = useState<"public" | "unlisted">("public");
  const [code, setCode] = useState("");
  const [customSlug, setCustomSlug] = useState("");
  const [obfuscation, setObfuscation] = useState<"ultra" | "strong" | "light" | "none">("ultra");
  const [inflation, setInflation] = useState<0 | 1 | 2 | 3>(2);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<CreateResult | null>(null);

  const lineCount = code ? code.split("\n").length : 0;
  const slugPreview = customSlug.trim() || "auto-generated-slug";

  const tags = useMemo(() => parseTags(tagInput), [tagInput]);

  const tagHint = useMemo(() => {
    const clean = tags.join("、");
    return clean ? `已选择 ${tags.length} 个标签：${clean}` : "用逗号分隔，最多 6 个标签";
  }, [tags]);

  function addTag(tag: string) {
    const next = tags.includes(tag) ? tags.filter((item) => item !== tag) : [...tags, tag].slice(0, 6);
    setTagInput(next.join(", "));
  }

  function handleCodeKeyDown(event: React.KeyboardEvent<HTMLTextAreaElement>) {
    if (event.key !== "Tab") return;
    event.preventDefault();
    const target = event.currentTarget;
    const start = target.selectionStart;
    const end = target.selectionEnd;
    const next = `${code.slice(0, start)}    ${code.slice(end)}`;
    setCode(next);
    requestAnimationFrame(() => {
      target.selectionStart = target.selectionEnd = start + 4;
    });
  }

  async function submit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setError(null);

    if (title.trim().length < 3) return setError("标题至少需要 3 个字符");
    if (code.trim().length < 10) return setError("脚本代码至少需要 10 个字符");
    if (customSlug && !/^[a-z0-9][a-z0-9-]{1,60}$/.test(customSlug.trim())) {
      return setError("短链只能包含小写字母、数字和连字符，且需以字母或数字开头");
    }

    setPending(true);
    try {
      const response = await fetch("/api/scripts", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim(),
          code,
          tags,
          authorName: authorName.trim() || "匿名",
          visibility,
          obfuscation,
          inflation,
          slug: customSlug.trim() || undefined,
          language: "luau",
        }),
      });
      const data = (await response.json()) as { script?: CreateResult; error?: string };
      if (!response.ok || !data.script) throw new Error(data.error ?? "上传失败，请稍后再试");

      setResult(data.script);
      rememberScript({ slug: data.script.slug, title: data.script.title, editKey: data.script.editKey });
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch (cause) {
      setError(cause instanceof Error ? cause.message : "上传失败，请稍后再试");
    } finally {
      setPending(false);
    }
  }

  if (result) {
    return (
      <div className="card glow-brand overflow-hidden">
        <div className="border-b border-line bg-lime/[0.06] px-6 py-5">
          <div className="flex items-center gap-3">
            <span className="grid h-9 w-9 place-items-center rounded-full bg-lime text-[15px] font-bold text-[#10130a]">
              ✓
            </span>
            <div>
              <h2 className="text-[16px] font-semibold text-white">托管成功，loadstring 已就绪</h2>
              <p className="text-[12.5px] text-zinc-400">
                代码已存储到数据库，刷新页面或分享链接都不会失效。
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-5 p-6">
          <div>
            <p className="label">在你的执行器中运行</p>
            <div className="flex flex-col gap-2 rounded-xl border border-line bg-[#080910] p-3 sm:flex-row sm:items-center">
              <code className="min-w-0 flex-1 overflow-x-auto whitespace-pre font-mono text-[12.5px] text-lime-300">
                {result.loadstring}
              </code>
              <CopyButton value={result.loadstring} label="复制 loadstring" variant="primary" />
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl border border-line bg-panel/60 p-3.5">
              <p className="font-mono text-[10px] uppercase tracking-wider text-zinc-500">signature raw endpoint · 勿公开</p>
              <div className="mt-2 flex items-center gap-2">
                <code className="min-w-0 flex-1 truncate font-mono text-[11.5px] text-zinc-300">
                  {result.rawUrl}
                </code>
                <CopyButton value={result.rawUrl} label="复制" className="!py-1 !text-[11px]" />
              </div>
            </div>
            <div className="rounded-xl border border-line bg-panel/60 p-3.5">
              <p className="font-mono text-[10px] uppercase tracking-wider text-zinc-500">页面链接</p>
              <div className="mt-2 flex items-center gap-2">
                <Link href={`/s/${result.slug}`} className="min-w-0 flex-1 truncate text-[12px] text-brand-2 hover:underline">
                  /s/{result.slug}
                </Link>
                <CopyButton value={result.pageUrl} label="复制" className="!py-1 !text-[11px]" />
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-amber-400/25 bg-amber-400/[0.06] p-4">
            <p className="text-[12.5px] font-medium text-amber-200">保管好你的编辑密钥（只显示一次）</p>
            <div className="mt-2 flex flex-col gap-2 sm:flex-row sm:items-center">
              <code className="flex-1 break-all rounded-lg border border-amber-400/20 bg-black/30 px-3 py-2 font-mono text-[11.5px] text-amber-100">
                {result.editKey}
              </code>
              <CopyButton value={result.editKey} label="复制密钥" className="!py-1.5" />
            </div>
            <p className="mt-2 text-[11.5px] text-amber-200/70">
              修改或删除脚本需要此密钥，我们已把它存在当前浏览器（我的托管）。更换设备后请手动导入。
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <Link href={`/s/${result.slug}`} className="btn btn-primary">
              查看脚本页面
            </Link>
            <Link href="/manage" className="btn btn-ghost">
              前往我的托管
            </Link>
            <button
              type="button"
              className="btn btn-ghost"
              onClick={() => {
                setResult(null);
                setTitle("");
                setDescription("");
                setCode("");
                setTagInput("");
                setCustomSlug("");
              }}
            >
              再托管一个
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <form onSubmit={submit} className="grid gap-6 lg:grid-cols-[1fr_360px]">
      <div className="space-y-5">
        <div className="card p-5">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="sm:col-span-2">
              <label className="label" htmlFor="title">
                脚本标题 <span className="text-brand-2">*</span>
              </label>
              <input
                id="title"
                value={title}
                onChange={(event) => setTitle(event.target.value)}
                maxLength={120}
                required
                placeholder="例如：Blox Fruits · 自动刷果实 v2"
                className="field"
              />
            </div>
            <div>
              <label className="label" htmlFor="author">
                作者署名
              </label>
              <input
                id="author"
                value={authorName}
                onChange={(event) => setAuthorName(event.target.value)}
                maxLength={40}
                placeholder="留空则显示「匿名」"
                className="field"
              />
            </div>
            <div>
              <label className="label" htmlFor="visibility">
                可见性
              </label>
              <div className="flex gap-2">
                {(
                  [
                    { key: "public", label: "公开", hint: "出现在列表" },
                    { key: "unlisted", label: "不公开", hint: "仅链接可访问" },
                  ] as const
                ).map((option) => (
                  <button
                    key={option.key}
                    type="button"
                    onClick={() => setVisibility(option.key)}
                    className={cn(
                      "flex-1 rounded-lg border px-3 py-2 text-left transition",
                      visibility === option.key
                        ? "border-brand/60 bg-brand/10"
                        : "border-line bg-white/[0.02] hover:border-zinc-600",
                    )}
                  >
                    <span className="block text-[12.5px] text-zinc-200">{option.label}</span>
                    <span className="block text-[10.5px] text-zinc-500">{option.hint}</span>
                  </button>
                ))}
              </div>
            </div>
            <div className="sm:col-span-2">
              <label className="label" htmlFor="description">
                简介
              </label>
              <textarea
                id="description"
                value={description}
                onChange={(event) => setDescription(event.target.value)}
                maxLength={500}
                rows={3}
                placeholder="说明脚本支持的游戏、功能和使用方式…"
                className="field resize-y"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="label">源码混淆（raw 接口返回的内容）</label>
              <div className="flex flex-wrap gap-2">
                {OBFUSCATION_OPTIONS.map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => setObfuscation(option.value)}
                    className={cn(
                      "flex-1 rounded-lg border px-3 py-2 text-left transition",
                      obfuscation === option.value
                        ? "border-brand/60 bg-brand/10"
                        : "border-line bg-white/[0.02] hover:border-zinc-600",
                    )}
                  >
                    <span className="block text-[12.5px] text-zinc-200">{option.label}</span>
                    <span className="block text-[10.5px] text-zinc-500">{option.hint}</span>
                  </button>
                ))}
              </div>
              <div className="mt-2">
                <label className="label !mb-1">动态膨胀（运行时生成填充数据与诱饵，参与解密）</label>
                <div className="flex flex-wrap gap-1.5">
                  {INFLATION_OPTIONS.map((option) => (
                    <button
                      key={option.value}
                      type="button"
                      onClick={() => setInflation(option.value)}
                      className={cn(
                        "flex-1 rounded-lg border px-2.5 py-1.5 text-left transition",
                        inflation === option.value
                          ? "border-lime/50 bg-lime/10"
                          : "border-line bg-white/[0.02] hover:border-zinc-600",
                      )}
                    >
                      <span className="block text-[12px] text-zinc-200">{option.label}</span>
                      <span className="block text-[10px] text-zinc-500">{option.hint}</span>
                    </button>
                  ))}
                </div>
              </div>
              <p className="mt-1.5 text-[11px] text-zinc-600">
                作者在后台仍能看到原始源码；raw 文件只返回引导器，加密载荷在运行时单独限时取回，
                所以静态抓包得到的文件里没有任何可解内容（不含 base64/hex）。
              </p>
            </div>
            <div className="sm:col-span-2">
              <label className="label" htmlFor="tags">
                标签
              </label>
              <input
                id="tags"
                value={tagInput}
                onChange={(event) => setTagInput(event.target.value)}
                placeholder="通用, 自动, 工具"
                className="field"
              />
              <div className="mt-2 flex flex-wrap gap-1.5">
                {TAG_SUGGESTIONS.map((tag) => (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => addTag(tag)}
                    className={cn("chip", tags.includes(tag) && "chip-active")}
                  >
                    {tags.includes(tag) ? "✓" : "+"} {tag}
                  </button>
                ))}
              </div>
              <p className="mt-1.5 text-[11px] text-zinc-600">{tagHint}</p>
            </div>
          </div>
        </div>

        <div className="card p-5">
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <div>
              <label className="label !mb-0" htmlFor="code">
                脚本代码 <span className="text-brand-2">*</span>
              </label>
              <p className="mt-1 text-[11px] text-zinc-600">
                {lineCount} 行 · {code.length} 字符 · 按 Tab 插入四个空格
              </p>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setCode(TEMPLATE)}
                className="btn btn-ghost !py-1.5 !text-[11.5px]"
              >
                插入模板
              </button>
              <button
                type="button"
                onClick={() => setCode("")}
                className="btn btn-ghost !py-1.5 !text-[11.5px]"
              >
                清空
              </button>
            </div>
          </div>
          <textarea
            id="code"
            value={code}
            onChange={(event) => setCode(event.target.value)}
            onKeyDown={handleCodeKeyDown}
            required
            spellCheck={false}
            placeholder={"-- 粘贴或编写你的 Luau 脚本\nprint(\"hello loadbin\")"}
            className="field min-h-[360px] resize-y font-mono !text-[12.5px] leading-[1.7]"
          />
        </div>

        {error && (
          <div className="rounded-xl border border-rose-500/30 bg-rose-500/[0.08] px-4 py-3 text-[12.5px] text-rose-300">
            {error}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <button type="submit" disabled={pending} className="btn btn-primary !px-5 disabled:opacity-60">
            {pending ? "正在上传…" : "托管并生成 loadstring"}
          </button>
          <p className="text-[11.5px] text-zinc-500">上传即表示你拥有该代码的分发权。</p>
        </div>
      </div>

      <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
        <div className="card p-4">
          <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-zinc-500">loadstring 预览</p>
          <pre className="mt-3 overflow-x-auto rounded-lg border border-line bg-[#080910] px-3 py-2.5 font-mono text-[11.5px] leading-relaxed text-lime-300">
            <code>
              {`loadstring(game:HttpGet("${baseUrl}/api/raw/${slugPreview}?key=••••"))()`}
            </code>
          </pre>
          <div className="mt-3">
            <label className="label" htmlFor="slug">
              自定义短链（可选）
            </label>
            <div className="flex items-center rounded-lg border border-line bg-[#080910] pl-2.5">
              <span className="shrink-0 font-mono text-[11px] text-zinc-600">/api/raw/</span>
              <input
                id="slug"
                value={customSlug}
                onChange={(event) =>
                  setCustomSlug(event.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ""))
                }
                maxLength={60}
                placeholder="my-script"
                className="w-full bg-transparent px-1.5 py-2 font-mono text-[12px] text-zinc-200 outline-none"
              />
            </div>
            <p className="mt-1.5 text-[11px] text-zinc-600">
              源码默认开启保护：不带签名的 raw 链接、浏览器直接打开都会被拒绝。
            </p>
          </div>
        </div>

        <div className="card p-4">
          <div className="mb-2 flex items-center justify-between">
            <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-zinc-500">代码预览</p>
            <span className="chip">{lineCount} 行</span>
          </div>
          {code.trim() ? (
            <CodeView code={code} maxHeight="20rem" className="!rounded-lg" />
          ) : (
            <div className="grid h-40 place-items-center rounded-lg border border-dashed border-line text-center text-[12px] text-zinc-600">
              左侧输入代码后
              <br />
              这里会显示高亮预览
            </div>
          )}
        </div>

        <div className="rounded-xl border border-line bg-panel/40 p-4">
          <p className="text-[12px] font-medium text-zinc-300">托管说明</p>
          <ul className="mt-2 space-y-1.5 text-[11.5px] leading-relaxed text-zinc-500">
            <li>· 代码原样返回，不会被修改或注入。</li>
            <li>· 带签名直链仅交给执行器，浏览器访问会被拒绝。</li>
            <li>· 每次执行都会计入调用统计。</li>
            <li>· 登录后上传的脚本可在账号中心管理。</li>
            <li>· 服务端混淆 + 签名直链，抓到的代码不可直接阅读。</li>
          </ul>
        </div>
      </aside>
    </form>
  );
}
