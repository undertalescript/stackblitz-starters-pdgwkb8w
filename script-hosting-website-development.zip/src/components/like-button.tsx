"use client";

import { useState } from "react";
import { cn, formatNumber } from "@/lib/format";

export function LikeButton({
  slug,
  initialLikes,
  initialLiked,
}: {
  slug: string;
  initialLikes: number;
  initialLiked: boolean;
}) {
  const [likes, setLikes] = useState(initialLikes);
  const [liked, setLiked] = useState(initialLiked);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function toggle() {
    if (pending) return;
    setPending(true);
    setError(null);

    const nextLiked = !liked;
    setLiked(nextLiked);
    setLikes((value) => Math.max(0, value + (nextLiked ? 1 : -1)));

    try {
      const response = await fetch(`/api/scripts/${slug}/like`, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: nextLiked ? "like" : "unlike" }),
      });
      const data = (await response.json()) as { likes?: number; liked?: boolean; error?: string };
      if (!response.ok) throw new Error(data.error ?? "操作失败");
      if (typeof data.likes === "number") setLikes(data.likes);
      if (typeof data.liked === "boolean") setLiked(data.liked);
    } catch (cause) {
      setLiked(!nextLiked);
      setLikes((value) => Math.max(0, value + (nextLiked ? -1 : 1)));
      setError(cause instanceof Error ? cause.message : "操作失败");
    } finally {
      setPending(false);
    }
  }

  return (
    <div className="flex flex-col gap-1.5">
      <button
        type="button"
        onClick={toggle}
        disabled={pending}
        className={cn(
          "btn w-full",
          liked ? "border-brand/60 bg-brand/15 text-brand-2" : "btn-ghost",
          "!justify-between",
        )}
      >
        <span className="flex items-center gap-2">
          <span className="text-[15px] leading-none">{liked ? "♥" : "♡"}</span>
          {liked ? "已收藏" : "收藏脚本"}
        </span>
        <span className="font-mono text-[12px] text-zinc-400">{formatNumber(likes)}</span>
      </button>
      {error && <p className="text-[11px] text-rose-400">{error}</p>}
    </div>
  );
}
