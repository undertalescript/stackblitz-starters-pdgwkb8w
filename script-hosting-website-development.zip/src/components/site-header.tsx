"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { cn } from "@/lib/format";
import { UserMenu, type HeaderUser } from "@/components/user-menu";

const NAV = [
  { href: "/scripts", label: "浏览脚本" },
  { href: "/docs", label: "API 文档" },
  { href: "/manage", label: "我的托管" },
];

export function SiteHeader({ user }: { user: HeaderUser | null }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`);

  return (
    <header className="sticky top-0 z-50 border-b border-line/80 bg-void/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-6 px-5">
        <Link href="/" className="group flex items-center gap-2.5" onClick={() => setOpen(false)}>
          <span className="relative grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-brand to-[#4c1d95] font-mono text-[13px] font-bold text-white shadow-[0_10px_24px_-12px_rgba(139,92,246,1)]">
            {"{ }"}
          </span>
          <span className="flex items-baseline gap-1.5">
            <span className="text-[15px] font-semibold tracking-tight text-white">loadbin</span>
            <span className="rounded border border-line bg-white/[0.03] px-1 py-0.5 font-mono text-[9px] uppercase tracking-widest text-zinc-500">
              beta
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {NAV.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "rounded-lg px-3 py-1.5 text-[13px] transition-colors",
                isActive(item.href)
                  ? "bg-white/[0.06] text-white"
                  : "text-zinc-400 hover:bg-white/[0.04] hover:text-zinc-100",
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto hidden items-center gap-2 md:flex">
          <span className="mr-1 flex items-center gap-1.5 font-mono text-[11px] text-zinc-500">
            <span className="h-1.5 w-1.5 rounded-full bg-lime shadow-[0_0_8px_#c8f75a]" />
            源码保护中
          </span>
          {user?.role === "admin" && (
            <Link
              href="/account#owner"
              className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-2.5 py-1.5 text-[12px] text-rose-200 transition hover:border-rose-400/60 hover:text-white"
            >
              ⚙ 控制台
            </Link>
          )}
          <Link href="/new" className="btn btn-primary !py-2 !text-[12.5px]">
            <span className="text-base leading-none">+</span> 上传脚本
          </Link>
          <UserMenu initialUser={user} />
        </div>

        <button
          type="button"
          aria-label="切换菜单"
          onClick={() => setOpen((value) => !value)}
          className="ml-auto grid h-9 w-9 place-items-center rounded-lg border border-line text-zinc-300 md:hidden"
        >
          <span className="flex flex-col gap-1">
            <span className={cn("h-0.5 w-4 bg-current transition", open && "translate-y-1.5 rotate-45")} />
            <span className={cn("h-0.5 w-4 bg-current transition", open && "opacity-0")} />
            <span className={cn("h-0.5 w-4 bg-current transition", open && "-translate-y-1.5 -rotate-45")} />
          </span>
        </button>
      </div>

      {open && (
        <div className="border-t border-line bg-panel/95 px-5 py-3 md:hidden">
          <div className="flex flex-col gap-1">
            {NAV.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className={cn(
                  "rounded-lg px-3 py-2 text-sm",
                  isActive(item.href) ? "bg-white/[0.06] text-white" : "text-zinc-400",
                )}
              >
                {item.label}
              </Link>
            ))}
            <Link href="/login" onClick={() => setOpen(false)} className="rounded-lg px-3 py-2 text-sm text-zinc-400">登录</Link>
            <Link href="/account" onClick={() => setOpen(false)} className="rounded-lg px-3 py-2 text-sm text-zinc-400">我的账号</Link>
            <Link
              href="/new"
              onClick={() => setOpen(false)}
              className="btn btn-primary mt-2 w-full"
            >
              上传脚本
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
