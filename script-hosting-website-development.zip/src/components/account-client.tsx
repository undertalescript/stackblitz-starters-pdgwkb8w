"use client";

import Link from "next/link";
import { useState } from "react";
import { CopyButton } from "@/components/copy-button";
import { cn, formatNumber, timeAgo } from "@/lib/format";

export type AccountScript = {
  slug: string;
  title: string;
  description: string;
  visibility: string;
  tags: string[];
  views: number;
  runs: number;
  likes: number;
  createdAt: string;
  updatedAt: string;
  codeLength: number;
  obfuscation?: string;
  inflation?: number;
  loadstring: string;
  rawUrl: string;
  pathUrl?: string;
};

export function AccountClient({ initial, username }: { initial: AccountScript[]; username: string }) {
  const [scripts, setScripts] = useState(initial);
  const [filter, setFilter] = useState("");
  const [busy, setBusy] = useState<string | null>(null);
  const [notice, setNotice] = useState<{ type: "ok" | "error"; text: string } | null>(null);

  const visible = scripts.filter((script) =>
    `${script.title} ${script.slug} ${script.tags.join(" ")}`.toLowerCase().includes(filter.toLowerCase()),
  );

  const totals = scripts.reduce(
    (acc, script) => ({
      views: acc.views + script.views,
      runs: acc.runs + script.runs,
      likes: acc.likes + script.likes,
    }),
    { views: 0, runs: 0, likes: 0 },
  );

  async function regenerate(slug: string) {
    if (!window.confirm("重置访问签名后，旧的 loadstring 链接会立即失效，需要重新复制。继续吗？")) return;
    setBusy(slug);
    setNotice(null);
    try {
      const response = await fetch(`/api/scripts/${slug}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ regenerateToken: true }),
      });
      const data = (await response.json()) as { error?: string; loadstring?: string; rawUrl?: string };
      if (!response.ok || !data.loadstring) throw new Error(data.error ?? "重置失败");
      setScripts((current) =>
        current.map((script) =>
          script.slug === slug
            ? { ...script, loadstring: data.loadstring!, rawUrl: data.rawUrl ?? script.rawUrl }
            : script,
        ),
      );
      setNotice({ type: "ok", text: "访问签名已重置，请重新复制 loadstring。" });
    } catch (cause) {
      setNotice({ type: "error", text: cause instanceof Error ? cause.message : "重置失败" });
    } finally {
      setBusy(null);
    }
  }

  async function remove(slug: string, title: string) {
    if (!window.confirm(`确定删除「${title}」？删除后所有 loadstring 链接立即失效。`)) return;
    setBusy(slug);
    setNotice(null);
    try {
      const response = await fetch(`/api/scripts/${slug}`, { method: "DELETE" });
      if (!response.ok && response.status !== 404) {
        const data = (await response.json().catch(() => ({}))) as { error?: string };
        throw new Error(data.error ?? "删除失败");
      }
      setScripts((current) => current.filter((script) => script.slug !== slug));
      setNotice({ type: "ok", text: "脚本已删除。" });
    } catch (cause) {
      setNotice({ type: "error", text: cause instanceof Error ? cause.message : "删除失败" });
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="space-y-5">
      <div className="grid gap-3 sm:grid-cols-4">
        {[
          { label: "我的脚本", value: formatNumber(scripts.length) },
          { label: "总浏览", value: formatNumber(totals.views) },
          { label: "执行次数", value: formatNumber(totals.runs) },
          { label: "收藏", value: formatNumber(totals.likes) },
        ].map((item) => (
          <div key={item.label} className="card px-4 py-3.5">
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-zinc-500">{item.label}</p>
            <p className="mt-1.5 text-[21px] font-semibold leading-none text-white">{item.value}</p>
          </div>
        ))}
      </div>

      {notice && (
        <div
          className={cn(
            "rounded-xl border px-4 py-3 text-[12.5px]",
            notice.type === "ok"
              ? "border-lime/30 bg-lime/[0.07] text-lime-200"
              : "border-rose-500/30 bg-rose-500/[0.08] text-rose-300",
          )}
        >
          {notice.text}
        </div>
      )}

      <div className="flex flex-wrap items-center gap-2">
        <input
          value={filter}
          onChange={(event) => setFilter(event.target.value)}
          placeholder="筛选我的脚本…"
          className="field max-w-xs !py-2 !text-[12.5px]"
        />
        <span className="font-mono text-[11px] text-zinc-600">{visible.length} / {scripts.length}</span>
        <span className="ml-auto flex items-center gap-1.5 font-mono text-[10.5px] uppercase tracking-wider text-lime-300">
          <span className="h-1.5 w-1.5 rounded-full bg-lime" /> {username} · 源码保护开启
        </span>
      </div>

      {visible.length === 0 ? (
        <div className="card grid place-items-center px-6 py-16 text-center">
          <div className="grid h-12 w-12 place-items-center rounded-xl border border-line bg-white/[0.03] text-xl">{"{}"}</div>
          <h3 className="mt-4 text-[15px] font-semibold text-white">
            {scripts.length === 0 ? "还没有托管脚本" : "没有匹配的脚本"}
          </h3>
          <p className="mt-2 max-w-sm text-[12.5px] leading-relaxed text-zinc-500">
            {scripts.length === 0
              ? "上传脚本后会自动绑定到你的账号，源码默认受到保护，只有执行器能读取。"
              : "换一个关键词试试。"}
          </p>
          <Link href="/new" className="btn btn-primary mt-5">上传脚本</Link>
        </div>
      ) : (
        <div className="space-y-3">
          {visible.map((script) => (
            <div key={script.slug} className="card p-4">
              <div className="flex flex-wrap items-start gap-4">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <Link href={`/s/${script.slug}`} className="truncate text-[14px] font-semibold text-white hover:text-brand-2">
                      {script.title}
                    </Link>
                    <span className="chip !border-lime/25 !bg-lime/10 !text-lime-300">🔒 源码保护</span>
                    <span className="chip !border-lime/25 !bg-lime/10 !text-lime-200">
                      膨胀 {script.inflation ?? 2}/3
                    </span>
                    <span className="chip !border-brand/30 !bg-brand/10 !text-brand-2">
                      {script.obfuscation === "none"
                        ? "未混淆"
                        : script.obfuscation === "light"
                          ? "轻量混淆"
                          : script.obfuscation === "strong"
                            ? "强混淆"
                            : "极限混淆"}
                    </span>
                    {script.visibility === "unlisted" && <span className="chip !text-amber-300">不公开</span>}
                  </div>
                  <p className="mt-1 font-mono text-[11px] text-zinc-500">
                    /api/raw/{script.slug} · {(script.codeLength / 1024).toFixed(1)} KB · 👁{" "}
                    {formatNumber(script.views)} · ▶ {formatNumber(script.runs)} · ♥ {formatNumber(script.likes)} ·{" "}
                    {timeAgo(script.updatedAt)}
                  </p>
                  <div className="mt-2.5 flex flex-wrap items-center gap-2">
                    <CopyButton value={script.loadstring} label="复制 loadstring" variant="lime" className="!py-1.5 !text-[11.5px]" />
                    <CopyButton value={script.rawUrl} label="复制签名直链" className="!py-1.5 !text-[11.5px]" />
                    {script.pathUrl && (
                      <CopyButton value={script.pathUrl} label="复制路径直链" className="!py-1.5 !text-[11.5px]" />
                    )}
                    <Link href={`/s/${script.slug}/raw`} className="btn btn-ghost !py-1.5 !text-[11.5px]">查看源码</Link>
                    <Link href={`/s/${script.slug}/edit`} className="btn btn-ghost !py-1.5 !text-[11.5px]">编辑</Link>
                    <button
                      type="button"
                      onClick={() => regenerate(script.slug)}
                      disabled={busy === script.slug}
                      className="btn btn-ghost !py-1.5 !text-[11.5px] disabled:opacity-60"
                    >
                      重置签名
                    </button>
                    <button
                      type="button"
                      onClick={() => remove(script.slug, script.title)}
                      disabled={busy === script.slug}
                      className="btn !py-1.5 !text-[11.5px] !border-rose-500/30 !bg-rose-500/10 !text-rose-300 disabled:opacity-60"
                    >
                      删除
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
