import { sql } from "drizzle-orm";
import {
  boolean,
  index,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 32 }).notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  /** "admin" = site owner, can switch script execution off site-wide. */
  role: varchar("role", { length: 16 }).notNull().default("user"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const siteSettings = pgTable("site_settings", {
  id: integer("id").primaryKey(),
  /** Master kill switch: when false no script can be loaded by any executor. */
  scriptsEnabled: boolean("scripts_enabled").notNull().default(true),
  maintenanceMode: boolean("maintenance_mode").notNull().default(false),
  announcement: text("announcement").notNull().default(""),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  updatedBy: varchar("updated_by", { length: 32 }),
});

export const sessions = pgTable(
  "sessions",
  {
    token: varchar("token", { length: 64 }).primaryKey(),
    userId: integer("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("sessions_user_id_idx").on(table.userId)],
);

export const scripts = pgTable(
  "scripts",
  {
    id: serial("id").primaryKey(),
    slug: varchar("slug", { length: 80 }).notNull().unique(),
    title: varchar("title", { length: 120 }).notNull(),
    description: text("description").notNull().default(""),
    code: text("code").notNull(),
    language: varchar("language", { length: 24 }).notNull().default("luau"),
    tags: jsonb("tags").$type<string[]>().notNull().default(sql`'[]'::jsonb`),
    authorName: varchar("author_name", { length: 60 }).notNull().default("匿名"),
    visibility: varchar("visibility", { length: 16 }).notNull().default("public"),
    editKey: varchar("edit_key", { length: 64 }).notNull(),
    /** Secret embedded in the loadstring URL — without it the source is refused. */
    accessToken: varchar("access_token", { length: 48 })
      .notNull()
      .default(sql`substr(md5(random()::text || clock_timestamp()::text), 1, 32)`),
    /** When true the source can never be read from a browser, only by the executor URL. */
    sourceProtected: boolean("source_protected").notNull().default(true),
    /** Site owner can block a single script without deleting it. */
    disabled: boolean("disabled").notNull().default(false),
    /** How the raw endpoint delivers the source: none | light | strong | ultra. */
    obfuscation: varchar("obfuscation", { length: 16 }).notNull().default("ultra"),
    /** Dynamic expansion level (0-3): runtime fill tables, decoy functions. */
    inflation: integer("inflation").notNull().default(2),
    ownerId: integer("owner_id").references(() => users.id, { onDelete: "set null" }),
    views: integer("views").notNull().default(0),
    runs: integer("runs").notNull().default(0),
    likes: integer("likes").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [
    index("scripts_created_at_idx").on(table.createdAt),
    index("scripts_owner_id_idx").on(table.ownerId),
  ],
);

export const comments = pgTable(
  "comments",
  {
    id: serial("id").primaryKey(),
    scriptId: integer("script_id")
      .notNull()
      .references(() => scripts.id, { onDelete: "cascade" }),
    authorName: varchar("author_name", { length: 60 }).notNull().default("匿名"),
    body: text("body").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [index("comments_script_id_idx").on(table.scriptId)],
);

export const scriptLikes = pgTable(
  "script_likes",
  {
    scriptId: integer("script_id")
      .notNull()
      .references(() => scripts.id, { onDelete: "cascade" }),
    visitorHash: varchar("visitor_hash", { length: 64 }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (table) => [primaryKey({ columns: [table.scriptId, table.visitorHash] })],
);

export type Script = typeof scripts.$inferSelect;
export type NewScript = typeof scripts.$inferInsert;
export type Comment = typeof comments.$inferSelect;
export type User = typeof users.$inferSelect;
export type SiteSettings = typeof siteSettings.$inferSelect;
