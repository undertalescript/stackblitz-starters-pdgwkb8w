import { and, desc, eq, ne, sql, ilike, or, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { comments, scriptLikes, scripts, users, type Script } from "@/db/schema";

export type SortKey = "trending" | "newest" | "popular";

export type ScriptListItem = Pick<
  Script,
  | "id"
  | "slug"
  | "title"
  | "description"
  | "language"
  | "tags"
  | "authorName"
  | "views"
  | "runs"
  | "likes"
  | "createdAt"
  | "updatedAt"
>;

/** Public view of a script — never contains the source code or secrets. */
export type ScriptMeta = Omit<Script, "editKey" | "code" | "accessToken"> & {
  sourceProtected: boolean;
};

/** Full record including source. Only returned for the owner / edit-key holder. */
export type ScriptDetail = Omit<Script, "editKey">;

export type PageResult = {
  items: ScriptListItem[];
  total: number;
  page: number;
  perPage: number;
  totalPages: number;
};

const listColumns = {
  id: scripts.id,
  slug: scripts.slug,
  title: scripts.title,
  description: scripts.description,
  language: scripts.language,
  tags: scripts.tags,
  authorName: scripts.authorName,
  views: scripts.views,
  runs: scripts.runs,
  likes: scripts.likes,
  createdAt: scripts.createdAt,
  updatedAt: scripts.updatedAt,
};

export function normalizeSort(sort?: string | null): SortKey {
  if (sort === "newest" || sort === "popular") return sort;
  return "trending";
}

export function normalizePage(page?: string | number | null): number {
  const value = typeof page === "number" ? page : Number.parseInt(page ?? "1", 10);
  return Number.isFinite(value) && value > 0 ? Math.min(Math.floor(value), 500) : 1;
}

export async function listScripts(options: {
  q?: string | null;
  tag?: string | null;
  sort?: SortKey;
  page?: number;
  perPage?: number;
}): Promise<PageResult> {
  const perPage = options.perPage ?? 9;
  const page = normalizePage(options.page);
  const sort = options.sort ?? "trending";

  const conditions: SQL[] = [eq(scripts.visibility, "public")];
  const q = options.q?.trim();
  if (q) {
    const pattern = `%${q.replace(/[%_]/g, (m) => `\\${m}`)}%`;
    const clause = or(ilike(scripts.title, pattern), ilike(scripts.description, pattern));
    if (clause) conditions.push(clause);
  }
  if (options.tag) {
    conditions.push(sql`${scripts.tags} @> ${JSON.stringify([options.tag])}::jsonb`);
  }

  const where = and(...conditions);
  const trending = sql`(${scripts.likes} * 6 + ${scripts.views} + ${scripts.runs} * 2)`;
  const orderBy =
    sort === "newest" ? desc(scripts.createdAt) : sort === "popular" ? desc(scripts.views) : desc(trending);

  const [items, totalRow] = await Promise.all([
    db
      .select(listColumns)
      .from(scripts)
      .where(where)
      .orderBy(orderBy)
      .limit(perPage)
      .offset((page - 1) * perPage),
    db.select({ count: sql<number>`count(*)::int` }).from(scripts).where(where),
  ]);

  const total = totalRow[0]?.count ?? 0;
  return {
    items,
    total,
    page,
    perPage,
    totalPages: Math.max(1, Math.ceil(total / perPage)),
  };
}

export async function getFeaturedScripts(limit = 3): Promise<ScriptListItem[]> {
  return db
    .select(listColumns)
    .from(scripts)
    .where(eq(scripts.visibility, "public"))
    .orderBy(desc(scripts.likes))
    .limit(limit);
}

export async function getRelatedScripts(script: ScriptDetail, limit = 3): Promise<ScriptListItem[]> {
  const tag = script.tags[0];
  const conditions: SQL[] = [eq(scripts.visibility, "public"), ne(scripts.id, script.id)];
  if (tag) conditions.push(sql`${scripts.tags} @> ${JSON.stringify([tag])}::jsonb`);

  const rows = await db
    .select(listColumns)
    .from(scripts)
    .where(and(...conditions))
    .orderBy(desc(scripts.likes))
    .limit(limit);

  if (rows.length > 0) return rows;

  return db
    .select(listColumns)
    .from(scripts)
    .where(and(eq(scripts.visibility, "public"), ne(scripts.id, script.id)))
    .orderBy(desc(scripts.likes))
    .limit(limit);
}

export async function getScriptBySlug(slug: string): Promise<ScriptDetail | null> {
  const rows = await db
    .select({
      id: scripts.id,
      slug: scripts.slug,
      title: scripts.title,
      description: scripts.description,
      code: scripts.code,
      language: scripts.language,
      tags: scripts.tags,
      authorName: scripts.authorName,
      visibility: scripts.visibility,
      ownerId: scripts.ownerId,
      accessToken: scripts.accessToken,
      sourceProtected: scripts.sourceProtected,
      disabled: scripts.disabled,
      obfuscation: scripts.obfuscation,
      inflation: scripts.inflation,
      views: scripts.views,
      runs: scripts.runs,
      likes: scripts.likes,
      createdAt: scripts.createdAt,
      updatedAt: scripts.updatedAt,
    })
    .from(scripts)
    .where(eq(scripts.slug, slug))
    .limit(1);

  return rows[0] ?? null;
}

/** Metadata-only lookup: safe to pass into client components. */
export async function getScriptMeta(slug: string): Promise<ScriptMeta | null> {
  const rows = await db
    .select({
      id: scripts.id,
      slug: scripts.slug,
      title: scripts.title,
      description: scripts.description,
      language: scripts.language,
      tags: scripts.tags,
      authorName: scripts.authorName,
      visibility: scripts.visibility,
      ownerId: scripts.ownerId,
      sourceProtected: scripts.sourceProtected,
      disabled: scripts.disabled,
      obfuscation: scripts.obfuscation,
      inflation: scripts.inflation,
      views: scripts.views,
      runs: scripts.runs,
      likes: scripts.likes,
      createdAt: scripts.createdAt,
      updatedAt: scripts.updatedAt,
    })
    .from(scripts)
    .where(eq(scripts.slug, slug))
    .limit(1);

  return rows[0] ?? null;
}

export async function getScriptsByOwner(ownerId: number) {
  return db
    .select({
      slug: scripts.slug,
      title: scripts.title,
      description: scripts.description,
      visibility: scripts.visibility,
      tags: scripts.tags,
      sourceProtected: scripts.sourceProtected,
      accessToken: scripts.accessToken,
      obfuscation: scripts.obfuscation,
      inflation: scripts.inflation,
      views: scripts.views,
      runs: scripts.runs,
      likes: scripts.likes,
      createdAt: scripts.createdAt,
      updatedAt: scripts.updatedAt,
      codeLength: sql<number>`length(${scripts.code})::int`,
    })
    .from(scripts)
    .where(eq(scripts.ownerId, ownerId))
    .orderBy(desc(scripts.createdAt));
}

export async function getOwnedScript(slug: string, ownerId: number) {
  const rows = await db
    .select()
    .from(scripts)
    .where(and(eq(scripts.slug, slug), eq(scripts.ownerId, ownerId)))
    .limit(1);
  return rows[0] ?? null;
}

export async function registerView(scriptId: number): Promise<void> {
  await db
    .update(scripts)
    .set({ views: sql`${scripts.views} + 1` })
    .where(eq(scripts.id, scriptId));
}

export async function getComments(scriptId: number) {
  return db
    .select({
      id: comments.id,
      authorName: comments.authorName,
      body: comments.body,
      createdAt: comments.createdAt,
    })
    .from(comments)
    .where(eq(comments.scriptId, scriptId))
    .orderBy(desc(comments.createdAt))
    .limit(30);
}

export async function getPlatformStats() {
  const [row] = await db
    .select({
      scripts: sql<number>`count(*)::int`,
      views: sql<number>`coalesce(sum(${scripts.views}), 0)::int`,
      likes: sql<number>`coalesce(sum(${scripts.likes}), 0)::int`,
      runs: sql<number>`coalesce(sum(${scripts.runs}), 0)::int`,
      week: sql<number>`(count(*) filter (where ${scripts.createdAt} > now() - interval '7 days'))::int`,
    })
    .from(scripts)
    .where(eq(scripts.visibility, "public"));

  const [commentRow] = await db.select({ count: sql<number>`count(*)::int` }).from(comments);

  return {
    scripts: row?.scripts ?? 0,
    views: row?.views ?? 0,
    likes: row?.likes ?? 0,
    runs: row?.runs ?? 0,
    week: row?.week ?? 0,
    comments: commentRow?.count ?? 0,
  };
}

export async function getTagCloud(limit = 12) {
  const rows = await db
    .select({ tags: scripts.tags })
    .from(scripts)
    .where(eq(scripts.visibility, "public"));

  const counts = new Map<string, number>();
  for (const row of rows) {
    for (const tag of row.tags ?? []) {
      counts.set(tag, (counts.get(tag) ?? 0) + 1);
    }
  }

  return [...counts.entries()]
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count || a.name.localeCompare(b.name))
    .slice(0, limit);
}

export async function hasLiked(scriptId: number, visitorHash: string): Promise<boolean> {
  const rows = await db
    .select({ scriptId: scriptLikes.scriptId })
    .from(scriptLikes)
    .where(and(eq(scriptLikes.scriptId, scriptId), eq(scriptLikes.visitorHash, visitorHash)))
    .limit(1);
  return rows.length > 0;
}

export type AdminScriptRow = {
  slug: string;
  title: string;
  authorName: string;
  ownerName: string | null;
  visibility: string;
  disabled: boolean;
  obfuscation: string;
  inflation: number;
  codeLength: number;
  views: number;
  runs: number;
  likes: number;
  createdAt: Date;
};

export async function getAllScriptsForAdmin(limit = 60): Promise<AdminScriptRow[]> {
  return db
    .select({
      slug: scripts.slug,
      title: scripts.title,
      authorName: scripts.authorName,
      ownerName: users.username,
      visibility: scripts.visibility,
      disabled: scripts.disabled,
      obfuscation: scripts.obfuscation,
      inflation: scripts.inflation,
      codeLength: sql<number>`length(${scripts.code})::int`,
      views: scripts.views,
      runs: scripts.runs,
      likes: scripts.likes,
      createdAt: scripts.createdAt,
    })
    .from(scripts)
    .leftJoin(users, eq(users.id, scripts.ownerId))
    .orderBy(desc(scripts.createdAt))
    .limit(limit);
}
