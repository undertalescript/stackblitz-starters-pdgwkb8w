import { randomBytes, randomInt } from "node:crypto";

export type ObfuscationMode = "none" | "light" | "strong" | "ultra";
export type InflateLevel = 0 | 1 | 2 | 3;

export const OBFUSCATION_MODES: { value: ObfuscationMode; label: string; hint: string }[] = [
  { value: "ultra", label: "极限（Shield v3）", hint: "状态机 VM + 加密字符串表 + 多层包裹 + 动态膨胀" },
  { value: "strong", label: "强", hint: "状态机 VM + 加密字符串表" },
  { value: "light", label: "轻量", hint: "状态机 VM，体积较小" },
  { value: "none", label: "不混淆", hint: "返回原始源码（作者自测用）" },
];

export const INFLATE_LEVELS: { value: InflateLevel; label: string; hint: string }[] = [
  { value: 0, label: "关闭膨胀", hint: "加载器最精简" },
  { value: 1, label: "标准膨胀", hint: "运行时填充表 + 掩码层" },
  { value: 2, label: "加强膨胀（默认）", hint: "填充表参与解密 + 诱饵函数" },
  { value: 3, label: "重度膨胀", hint: "更大填充表与更多诱饵，启动略慢" },
];

export function normalizeObfuscation(value: unknown): ObfuscationMode {
  return value === "none" || value === "light" || value === "strong" || value === "ultra"
    ? value
    : "ultra";
}

export function normalizeInflation(value: unknown): InflateLevel {
  const parsed = typeof value === "string" ? Number.parseInt(value, 10) : value;
  return parsed === 0 || parsed === 1 || parsed === 3 ? parsed : 2;
}

export function obfuscationLabel(mode: ObfuscationMode): string {
  switch (mode) {
    case "none":
      return "未混淆";
    case "light":
      return "轻量";
    case "strong":
      return "强";
    default:
      return "极限（Shield v3）";
  }
}

/* ================================================================== *
 * Cipher — all intermediates stay below 2^31 so 32-bit integer Lua
 * builds produce the same bytes as double builds.
 * ================================================================== */

const P1 = 65521;
const P2 = 65519;
const PAD_MUL = 7919;
const PAD_ADD = 12345;
const MASK_A_MUL = 269;
const MASK_A_ADD = 911;
const MASK_B_MUL = 263;
const MASK_B_ADD = 7919;

class Keystream {
  private s1: number;
  private s2: number;

  constructor(seed: number) {
    this.s1 = (Math.abs(Math.floor(seed)) % (P1 - 1)) + 1;
    this.s2 = (Math.abs(Math.floor(seed * 7 + 13)) % (P2 - 1)) + 1;
  }

  private step(): void {
    this.s1 = (this.s1 * 251 + 12345) % P1;
    this.s2 = (this.s2 * 241 + 54321) % P2;
  }

  byte(): number {
    this.step();
    return (this.s1 + this.s2 * 7) % 256;
  }

  below(bound: number): number {
    this.step();
    return (this.s1 * 157 + this.s2) % bound;
  }
}

function buildSbox(rng: Keystream): { box: number[]; inverse: number[] } {
  const box = Array.from({ length: 256 }, (_, index) => index);
  for (let index = 255; index > 0; index -= 1) {
    const swapWith = rng.below(index + 1);
    const swap = box[index];
    box[index] = box[swapWith];
    box[swapWith] = swap;
  }
  const inverse = new Array<number>(256);
  for (let index = 0; index < 256; index += 1) inverse[box[index]] = index;
  return { box, inverse };
}

function xor8(a: number, b: number): number {
  let result = 0;
  let bit = 1;
  let x = a;
  let y = b;
  for (let index = 0; index < 8; index += 1) {
    if (x % 2 !== y % 2) result += bit;
    x = Math.floor(x / 2);
    y = Math.floor(y / 2);
    bit *= 2;
  }
  return result;
}

function rotl(byte: number, amount: number): number {
  const shift = amount % 8;
  if (shift === 0) return byte;
  return (Math.floor(byte / 2 ** (8 - shift)) + ((byte * 2 ** shift) % 256)) % 256;
}

function rotr(byte: number, amount: number): number {
  const shift = amount % 8;
  if (shift === 0) return byte;
  return (Math.floor(byte / 2 ** shift) + ((byte * 2 ** (8 - shift)) % 256)) % 256;
}

function encryptBytes(source: Uint8Array, seed: number, key: number[]): number[] {
  const rng = new Keystream(seed);
  const { box } = buildSbox(rng);
  const output: number[] = new Array(source.length);
  for (let index = 0; index < source.length; index += 1) {
    const k1 = key[index % key.length];
    const k2 = rng.byte();
    let byte = xor8(source[index], k1);
    byte = (byte + k2 + (index % 251)) % 256;
    byte = box[byte];
    output[index] = rotl(byte, (index % 7) + 1);
  }
  return output;
}

/** Mirror of the emitted decoder (kept for tests / self-check). */
export function decryptBytes(cipher: number[], seed: number, key: number[]): string {
  const rng = new Keystream(seed);
  const { inverse } = buildSbox(rng);
  const out = new Uint8Array(cipher.length);
  for (let index = 0; index < cipher.length; index += 1) {
    const k1 = key[index % key.length];
    const k2 = rng.byte();
    let byte = rotr(cipher[index], (index % 7) + 1);
    byte = inverse[byte];
    byte = (byte - k2 - (index % 251) + 512) % 256;
    out[index] = xor8(byte, k1);
  }
  return new TextDecoder().decode(out);
}

function padValue(index: number): number {
  return (index * PAD_MUL + PAD_ADD) % P1;
}

function buildMaskLayer(cipher: number[], seed2: number, padLen: number): { stored: number[]; mask: number[] } {
  if (padLen === 0) return { stored: [...cipher], mask: cipher.map(() => 0) };
  let a = (Math.abs(Math.floor(seed2)) % (P1 - 1)) + 1;
  let b = (Math.abs(Math.floor(seed2 * 5 + 29)) % (P2 - 1)) + 1;
  const mask: number[] = [];
  for (let index = 0; index < cipher.length; index += 1) {
    a = (a * MASK_A_MUL + MASK_A_ADD) % P1;
    b = (b * MASK_B_MUL + MASK_B_ADD) % P2;
    const stream = (a + b * 11) % 256;
    const fill = padLen > 0 ? padValue((index % padLen) + 1) % 256 : 0;
    mask.push(xor8(stream, fill));
  }
  return { stored: cipher.map((byte, index) => xor8(byte, mask[index])), mask };
}

function integrity(bytes: Uint8Array): [number, number] {
  let a = 11;
  let b = 23;
  for (const byte of bytes) {
    a = (a * 31 + byte) % P1;
    b = (b * 17 + byte) % P2;
  }
  return [a, b];
}

export const INFLATE_PROFILE: Record<InflateLevel, { padLen: number; bloat: number; junk: number }> = {
  0: { padLen: 0, bloat: 0, junk: 0 },
  1: { padLen: 32, bloat: 40, junk: 2 },
  2: { padLen: 96, bloat: 240, junk: 5 },
  3: { padLen: 256, bloat: 900, junk: 10 },
};

/* ================================================================== *
 * Emitter helpers
 * ================================================================== */

const ID_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_";
const usedIds = new Set<string>();

function rid(prefix = "_", min = 5, max = 13): string {
  for (let attempt = 0; attempt < 64; attempt += 1) {
    const length = min + (randomBytes(1)[0] % (max - min + 1));
    let out = prefix;
    for (let index = 0; index < length; index += 1) {
      out += ID_CHARS[randomBytes(1)[0] % ID_CHARS.length];
    }
    if (!usedIds.has(out)) {
      usedIds.add(out);
      return out;
    }
  }
  return `${prefix}${Math.random().toString(36).slice(2, 10)}`;
}

/** Hide constants inside arithmetic like the reference does. */
function bake(value: number): string {
  // Never emit negative constants via subtraction chains: `--` would start a comment.
  const a = randomInt(3, 900);
  const b = randomInt(3, 61);
  if (value < 0) return `(${a * b}+${value + a * b})`;
  switch (randomInt(0, 3)) {
    case 0:
      return `(${value + a * b}-${a * b})`;
    case 1:
      return `(${value * 2}-${value})`;
    case 2:
      return `(${a * b}+${value}-${a * b})`;
    default:
      return `(${value}+${a}-${a})`;
  }
}

function numberBlock(values: number[], perLine = 16): string {
  const lines: string[] = [];
  for (let index = 0; index < values.length; index += perLine) {
    lines.push(values.slice(index, index + perLine).join(","));
  }
  return `{${lines.join(",\n")}}`;
}

function shuffle<T>(input: T[]): T[] {
  const list = [...input];
  for (let index = list.length - 1; index > 0; index -= 1) {
    const swapWith = randomBytes(1)[0] % (index + 1);
    const swap = list[index];
    list[index] = list[swapWith];
    list[swapWith] = swap;
  }
  return list;
}

function packNumbers(cipher: number[]): number[] {
  const packed: number[] = [];
  for (let index = 0; index < cipher.length; index += 3) {
    const b0 = cipher[index] ?? 0;
    const b1 = cipher[index + 1] ?? 0;
    const b2 = cipher[index + 2] ?? 0;
    packed.push(b0 + b1 * 256 + b2 * 65536);
  }
  return packed;
}

/** Encrypt the loader's own strings (no readable literals in the output). */
function sealStrings(messages: string[]): { table: string; key: number; indexes: number[] } {
  const key = randomInt(1, 250);
  const rows = messages.map((message) => {
    const bytes = [...new TextEncoder().encode(message)];
    return { key, values: bytes.map((byte, index) => xor8(byte, (key * 37 + index * 13 + 7) % 256)) };
  });
  // decoy rows so real messages are not the only entries
  const decoys = Array.from({ length: 8 + (randomBytes(1)[0] % 14) }, () => {
    const length = 3 + (randomBytes(1)[0] % 9);
    return {
      key,
      values: Array.from({ length }, () => randomInt(0, 255)),
    };
  });
  const tagged = shuffle([
    ...rows.map((row, index) => ({ ...row, msgIndex: index })),
    ...decoys.map((row) => ({ ...row, msgIndex: -1 })),
  ]);
  const table = tagged.map((row) => numberBlock(row.values, 12)).join(",\n");
  const indexes = new Array<number>(messages.length).fill(0);
  tagged.forEach((row, position) => {
    if (row.msgIndex >= 0) indexes[row.msgIndex] = position + 1;
  });
  return { table: `{\n${table}\n}`, key, indexes };
}

/* ================================================================== *
 * State-machine VM emitter (CodeX-style hashed dispatch)
 * ================================================================== */

type VmPlan = {
  seed: number;
  seed2: number;
  key: number[];
  cipher: number[];
  mask: number[];
  packed: number[];
  hash: [number, number];
  length: number;
  inflation: InflateLevel;
  mode: ObfuscationMode;
};

export function obfuscate(
  source: string,
  mode: ObfuscationMode = "ultra",
  options?: { inflation?: InflateLevel; debug?: Record<string, unknown> },
): string {
  if (mode === "none") return source;

  const inflation = normalizeInflation(options?.inflation ?? (mode === "light" ? 0 : 2));
  const profile = INFLATE_PROFILE[inflation];
  const ultra = mode === "ultra";
  const strong = mode !== "light";

  usedIds.clear();

  const bytes = new TextEncoder().encode(source);
  const seed = randomInt(1, P1 - 2);
  const key = Array.from({ length: 16 }, () => randomInt(0, 256));
  const cipher = encryptBytes(bytes, seed, key);
  const seed2 = randomInt(1, P1 - 2);
  const { stored, mask } = buildMaskLayer(cipher, seed2, profile.padLen);
  const packed = packNumbers(stored);

  const plan: VmPlan = {
    seed,
    seed2,
    key,
    cipher,
    mask,
    packed,
    hash: integrity(bytes),
    length: bytes.length,
    inflation,
    mode,
  };
  if (options?.debug) Object.assign(options.debug, plan);

  // ---- identifiers (CodeX-like random names) ----
  const id = {
    byte: rid("_", 5, 10),
    sub: rid("_", 5, 10),
    char: rid("_", 5, 10),
    concat: rid("_", 5, 10),
    floor: rid("_", 5, 10),
    pcall: rid("_", 5, 10),
    type: rid("_", 5, 10),
    unpack: rid("_", 5, 10),
    mod: rid("_", 5, 10),
    state: rid("_", 6, 12),
    dispatch: rid("_", 5, 10),
    selectorFn: rid("_", 5, 10),
    xorT: rid("_", 5, 10),
    xorFn: rid("_", 5, 10),
    rot: rid("_", 5, 10),
    ksA: rid("_", 4, 8),
    ksB: rid("_", 4, 8),
    nextByte: rid("_", 5, 10),
    nextIdx: rid("_", 5, 10),
    sbox: rid("_", 4, 8),
    inv: rid("_", 4, 8),
    keyArr: rid("_", 5, 10),
    padArr: rid("_", 5, 10),
    bloatArr: rid("_", 5, 10),
    maskA: rid("_", 4, 8),
    maskB: rid("_", 4, 8),
    maskStep: rid("_", 5, 10),
    chunks: rid("_", 5, 10),
    order: rid("_", 5, 10),
    flat: rid("_", 5, 10),
    regs: rid("_", 4, 8),
    out: rid("_", 4, 8),
    src: rid("_", 5, 10),
    fn: rid("_", 5, 10),
    err: rid("_", 4, 8),
    strings: rid("_", 5, 10),
    strKey: rid("_", 4, 8),
    msg: rid("_", 5, 10),
    wi: rid("_", 2, 4),
    word: rid("_", 2, 4),
    lane: rid("_", 2, 4),
    tmp: rid("_", 2, 4),
    idx: rid("_", 2, 4),
    h1: rid("_", 2, 3),
    h2: rid("_", 2, 3),
    guard: rid("_", 5, 10),
  };

  const lines: string[] = [];
  lines.push(`-- Protected by loadbin Shield v3`);
  lines.push(`-- state-machine VM · packed numeric payload · no base64/hex`);

  // ---- hoisted stdlib aliases (mimics reference) ----
  lines.push(
    `local ${id.byte},${id.sub},${id.char},${id.concat},${id.floor},${id.pcall},${id.type},${id.unpack}=string.byte,string.sub,string.char,table.concat,math.floor,pcall,type,table.unpack`,
  );

  // ---- encrypted string table (declared first, decoded after xorFn exists) ----
  const messages = [
    "integrity check failed",
    "protected build failed: ",
    "decode aborted",
    "loadbin",
    "execution blocked",
  ];
  const sealed = sealStrings(messages);
  lines.push(`local ${id.strKey}=${bake(sealed.key)}`);
  lines.push(`local ${id.strings}=${sealed.table}`);

  // ---- core primitives ----
  lines.push(`local ${id.xorT}={}`);
  lines.push(`for a=0,15 do ${id.xorT}[a]={} for b=0,15 do`);
  lines.push(`  local r,m=0,1 for k=0,3 do`);
  lines.push(`    if ${id.floor}(a/m)%2~=${id.floor}(b/m)%2 then r=r+m end m=m*2`);
  lines.push(`  end ${id.xorT}[a][b]=r`);
  lines.push(`end end`);
  lines.push(
    `local function ${id.xorFn}(a,b) return ${id.xorT}[${id.floor}(a/16)][${id.floor}(b/16)]*16+${id.xorT}[a%16][b%16] end`,
  );
  lines.push(`local function ${id.msg}(k)`);
  lines.push(`  local r=${id.strings}[k] local t={} for i=1,#r do`);
  lines.push(
    `    t[i]=${id.char}(${id.xorFn}(r[i],(${id.strKey}*37+(i-1)*13+7)%256))`,
  );
  lines.push(`  end return ${id.concat}(t) end`);
  lines.push(
    `local function ${id.rot}(b,r) if r==0 then return b end return ${id.floor}(b/2^r)%256+(b*2^(8-r))%256 end`,
  );
  lines.push(`-- decode stage: rotate right then inverse s-box`);
  lines.push(
    `local ${id.ksA},${id.ksB}=${bake(seed % 65520 + 1)},${bake((seed * 7 + 13) % 65518 + 1)}`,
  );
  lines.push(
    `local function ${id.nextIdx}() ${id.ksA}=(${id.ksA}*251+12345)%65521 ${id.ksB}=(${id.ksB}*241+54321)%65519 end`,
  );
  lines.push(
    `local function ${id.nextByte}() ${id.nextIdx}() return (${id.ksA}+${id.ksB}*7)%256 end`,
  );
  lines.push(`local ${id.sbox}={} for i=0,255 do ${id.sbox}[i]=i end`);
  lines.push(
    `for i=255,1,-1 do ${id.nextIdx}() local j=(${id.ksA}*157+${id.ksB})%(i+1) ${id.sbox}[i],${id.sbox}[j]=${id.sbox}[j],${id.sbox}[i] end`,
  );
  lines.push(`local ${id.inv}={} for i=0,255 do ${id.inv}[${id.sbox}[i]]=i end`);
  lines.push(`local ${id.keyArr}={${key.map((value) => bake(value)).join(",")}}`);
  lines.push(`setmetatable(${id.keyArr},{__index=function(t,k) return rawget(t,((k-1)%#t)+1) end})`);

  if (profile.padLen > 0) {
    lines.push(
      `local ${id.padArr}={} for i=1,${bake(profile.padLen)} do ${id.padArr}[i]=(i*${PAD_MUL}+${PAD_ADD})%65521 end`,
    );
    lines.push(
      `local ${id.maskA},${id.maskB}=${bake(seed2 % 65520 + 1)},${bake((seed2 * 5 + 29) % 65518 + 1)}`,
    );
    lines.push(
      `local function ${id.maskStep}() ${id.maskA}=(${id.maskA}*${MASK_A_MUL}+${MASK_A_ADD})%65521 ${id.maskB}=(${id.maskB}*${MASK_B_MUL}+${MASK_B_ADD})%65519 return ${id.maskA},${id.maskB} end`,
    );
  }
  if (profile.bloat > 0) {
    lines.push(`local ${id.bloatArr}={} for i=1,${bake(profile.bloat)} do`);
    lines.push(
      `  ${id.bloatArr}[i]=(${id.padArr}[(i%#${id.padArr})+1]+i*31+${id.keyArr}[i%#${id.keyArr}+1])%65521`,
    );
    lines.push(`end`);
    lines.push(
      `if (${id.bloatArr}[#${id.bloatArr}]-${id.bloatArr}[#${id.bloatArr}])~=0 then return warn(${id.msg}(${sealed.indexes[2]})) end`,
    );
  }

  // ---- payload chunk tables (with decoys) ----
  const chunkSize = ultra ? 400 : 2200;
  const real: { id: string; values: number[] }[] = [];
  for (let index = 0; index < packed.length; index += chunkSize) {
    real.push({ id: rid("", 6, 11), values: packed.slice(index, index + chunkSize) });
  }
  const decoys: { id: string; values: number[] }[] = [];
  if (strong) {
    const decoyCount = Math.max(2, Math.ceil(real.length * (ultra ? 0.6 : 0.25)));
    for (let index = 0; index < decoyCount; index += 1) {
      const length = 20 + (randomBytes(1)[0] % 70);
      decoys.push({ id: rid("", 6, 11), values: Array.from({ length }, () => randomInt(0, 16777215)) });
    }
  }
  const storedChunks = ultra ? shuffle([...real, ...decoys]) : [...real, ...decoys];
  lines.push(`local ${id.chunks}={`);
  lines.push(storedChunks.map((chunk) => `["${chunk.id}"]=${numberBlock(chunk.values)}`).join(",\n"));
  lines.push(`}`);
  lines.push(`local ${id.order}={${real.map((chunk) => `"${chunk.id}"`).join(",")}}`);

  // ---- junk functions (dead code) ----
  for (let index = 0; index < profile.junk; index += 1) {
    const fn = rid("_", 5, 10);
    const arg = rid("_", 2, 3);
    const tbl = rid("_", 3, 6);
    lines.push(
      `local function ${fn}(${arg}) local ${tbl}={} for i=1,(${arg}%9)+1 do ${tbl}[i]=(i*${randomInt(7, 977)}+${bake(randomInt(3, 40000))})%65521 end return ${tbl} end`,
    );
  }

  // ---- hashed state dispatch ----
  // Keep every intermediate small: Lua builds with 32-bit integers and float
  // builds must agree on the dispatch value, so nothing exceeds ~1e8.
  const hashA = randomInt(101, 997);
  const hashB = randomInt(101, 9973);
  const hashP = 1000003;
  const steps = 9;
  const states: number[] = [];
  const selectors: number[] = [];
  const seen = new Set<number>();
  while (states.length < steps) {
    const candidate = randomInt(1000, 90000);
    const selector = (candidate * hashA + hashB) % hashP;
    if (seen.has(selector)) continue;
    seen.add(selector);
    states.push(candidate);
    selectors.push(selector);
  }
  const [stInit, stLoad, stByte, stNext, stJoin, stGuard, stLoad2, stRun, stFail] = states;
  const selectorFor = (state: number) => (state * hashA + hashB) % hashP;
  if (options?.debug) Object.assign(options.debug, { states, selectors, hashA, hashB, hashP, selectorFor });

  lines.push(`local ${id.regs}={0,0,0,0,0}`);
  lines.push(`local ${id.out}={}`);
  lines.push(`local ${id.flat}=nil`);
  lines.push(`local ${id.src},${id.fn},${id.err}=nil,nil,nil`);
  lines.push(`local function ${id.selectorFn}(a,b) local r=a%b if r<0 then r=r+b end return r end`);
  lines.push(`local function ${id.guard}() if ${id.flat} then return #${id.flat} end return -1 end`);
  lines.push(`local ${id.state}=${stInit}`);
  lines.push(`while ${id.state} do`);
  lines.push(`  local ${id.dispatch}=${id.selectorFn}(${id.state}*${hashA}+${hashB},${hashP})`);

  const branches: { selector: number; body: string[] }[] = [];

  // init: flatten chunks
  branches.push({
    selector: selectors[0],
    body: [
      `local t={} for i=1,#${id.order} do local k=${id.order}[i] local c=${id.chunks}[k] for j=1,#c do t[#t+1]=c[j] end end`,
      `${id.flat}=t ${id.regs}[1]=0 ${id.regs}[5]=0`,
      `${id.state}=${stLoad}`,
    ],
  });

  // word fetch
  branches.push({
    selector: selectors[1],
    body: [
      `if ${id.regs}[1]>=#${id.flat} then ${id.state}=${stJoin} else`,
      `  ${id.regs}[2]=${id.flat}[${id.regs}[1]+1] ${id.regs}[3]=0`,
      `  ${id.state}=${stByte}`,
      `end`,
    ],
  });

  // per-byte pipeline
  branches.push({
    selector: selectors[2],
    body: [
      `local x=${id.regs}[2]%256`,
      `local i=${id.regs}[5]`,
      profile.padLen > 0
        ? `  local ma,mb=${id.maskStep}() x=${id.xorFn}(x,${id.xorFn}((ma+mb*11)%256,${id.padArr}[(i%#${id.padArr})+1]%256))`
        : `  if i<0 then x=x end`,
      `x=${id.rot}(x,(i%7)+1) x=${id.inv}[x] x=(x-${id.nextByte}()-(i%251))%256`,
      `x=${id.xorFn}(x,${id.keyArr}[i%#${id.keyArr}+1])`,
      profile.bloat > 0
        ? `if ${id.bloatArr}[i%#${id.bloatArr}+1]<0 then x=x end`
        : `if i<-1 then x=x end`,
      `${id.out}[#${id.out}+1]=${id.char}(x)`,
      `${id.regs}[5]=${id.regs}[5]+1 ${id.regs}[2]=${id.floor}(${id.regs}[2]/256) ${id.regs}[3]=${id.regs}[3]+1`,
      `${id.state}=(${id.regs}[3]<3) and ${stByte} or ${stNext}`,
    ],
  });

  // next word
  branches.push({
    selector: selectors[3],
    body: [`${id.regs}[1]=${id.regs}[1]+1`, `${id.state}=${stLoad}`],
  });

  // join + truncate
  branches.push({
    selector: selectors[4],
    body: [
      `${id.flat}=nil`,
      `${id.src}=${id.sub}(${id.concat}(${id.out}),1,${bake(bytes.length)})`,
      `${id.out}=nil`,
      `${id.state}=${stGuard}`,
    ],
  });

  // integrity guard
  branches.push({
    selector: selectors[5],
    body: [
      `local a,b=11,23`,
      `for i=1,#${id.src} do local v=${id.byte}(${id.src},i) a=(a*31+v)%65521 b=(b*17+v)%65519 end`,
      `if a~=${bake(plan.hash[0])} or b~=${bake(plan.hash[1])} then ${id.err}=${id.msg}(${sealed.indexes[0]}) ${id.state}=${stFail} else ${id.state}=${stLoad2} end`,
    ],
  });

  // compile
  branches.push({
    selector: selectors[6],
    body: [
      `${id.fn},${id.err}=loadstring(${id.src})`,
      `${id.src}=nil`,
      `if not ${id.fn} then ${id.err}=${id.msg}(${sealed.indexes[1]})..tostring(${id.err}) ${id.state}=${stFail} else ${id.state}=${stRun} end`,
    ],
  });

  // run
  branches.push({
    selector: selectors[7],
    body: [
      `local ok,msg=${id.pcall}(${id.fn}) ${id.fn}=nil`,
      `if not ok then return warn(${id.msg}(${sealed.indexes[3]})..tostring(msg)) end`,
      `${id.state}=false`,
    ],
  });

  // fail
  branches.push({
    selector: selectors[8],
    body: [`return warn(${id.err} or ${id.msg}(${sealed.indexes[4]}))`],
  });

  shuffle(branches).forEach((branch, index) => {
    lines.push(`  ${index === 0 ? "if" : "elseif"} ${id.dispatch}==${branch.selector} then`);
    for (const body of branch.body) lines.push(`    ${body}`);
    lines.push(index === branches.length - 1 ? `  else ${id.state}=false` : "");
  });
  lines.push(`  end`);
  lines.push(`end`);

  // ---- opaque predicate: only trips on impossible runtime state ----
  const impossible = randomInt(4242, 98765);
  lines.push(
    `if ((${id.guard}() + 1) * 0 + ${impossible}) == ${impossible + randomInt(1, 999)} then return warn(${id.msg}(${sealed.indexes[2]})) end`,
  );

  // ---- nested wrapper layers (mimic reference IIFE chain) ----
  const layers = mode === "light" ? 1 : strong ? 2 : 3;
  let body = lines.join("\n");
  for (let index = 0; index < layers; index += 1) {
    const p1 = rid("_", 3, 6);
    const p2 = rid("_", 3, 6);
    const junk = rid("_", 4, 8);
    body = `return(function(${p1},${p2},...) local ${junk}=(${p1}*${randomInt(3, 97)}+${p2})%${randomInt(1009, 99991)}
${body}
end)(${randomInt(2, 900)},${randomInt(2, 900)},...)`;
  }

  return `${body}\n`;
}

/** Decode a packed payload (self-check helper). */
export function decodeProtectedPayload(packed: number[], seed: number, key: number[]): string {
  const cipher: number[] = [];
  for (const word of packed) {
    cipher.push(word % 256, Math.floor(word / 256) % 256, Math.floor(word / 65536) % 256);
  }
  return decryptBytes(cipher, seed, key);
}

/* ================================================================== *
 * Two-stage shield: the served raw file carries NO payload at all.
 *  - stage 1 (raw): bootstrap VM, fetches the ciphertext at runtime
 *  - stage 2 (/api/stage): short-lived signed ciphertext blob
 * Static analysis of the raw file therefore has nothing to decode.
 * ================================================================== */

export type TwoStage = { stub: string; stage: string };

export function buildTwoStage(
  source: string,
  stageUrl: string,
  options?: {
    inflation?: InflateLevel;
    failureLabel?: string;
    debug?: Record<string, unknown>;
    /** Deterministic material so both stages derive the same ciphertext. */
    seedOverride?: number;
    keyOverride?: number[];
  },
): TwoStage {
  const inflation = normalizeInflation(options?.inflation ?? 2);
  const profile = INFLATE_PROFILE[inflation];

  usedIds.clear();
  const bytes = new TextEncoder().encode(source);
  const seed = options?.seedOverride ?? randomInt(1, P1 - 2);
  const key = options?.keyOverride ?? Array.from({ length: 16 }, () => randomInt(0, 256));
  const cipher = encryptBytes(bytes, seed, key);
  const packed = packNumbers(cipher);
  const [hashA, hashB] = integrity(bytes);

  // stage body: packed ciphertext + trailing decoys (numeric CSV, nothing readable)
  const decoys = Array.from({ length: profile.padLen * 2 + 8 }, () => randomInt(0, 16777215));
  const stage = [...packed, ...decoys].join(",");

  const id = {
    xorT: rid("_", 5, 10),
    xor: rid("_", 5, 10),
    rot: rid("_", 5, 10),
    ksA: rid("_", 4, 8),
    ksB: rid("_", 4, 8),
    step: rid("_", 5, 10),
    nbyte: rid("_", 5, 10),
    nidx: rid("_", 5, 10),
    box: rid("_", 4, 8),
    inv: rid("_", 4, 8),
    key: rid("_", 5, 10),
    words: rid("_", 5, 10),
    out: rid("_", 4, 8),
    src: rid("_", 4, 8),
    fn: rid("_", 4, 8),
    err: rid("_", 4, 8),
    body: rid("_", 5, 10),
    ok: rid("_", 3, 5),
    i: rid("_", 2, 3),
    j: rid("_", 2, 3),
  };

  const lines: string[] = [];
  lines.push(`-- Protected by loadbin Shield v3 · staged (no payload in this file)`);
  lines.push(`local ${id.xorT}={}`);
  lines.push(`for a=0,15 do ${id.xorT}[a]={} for b=0,15 do`);
  lines.push(`  local r,m=0,1 for k=0,3 do`);
  lines.push(`    if math.floor(a/m)%2~=math.floor(b/m)%2 then r=r+m end m=m*2`);
  lines.push(`  end ${id.xorT}[a][b]=r`);
  lines.push(`end end`);
  lines.push(
    `local function ${id.xor}(a,b) return ${id.xorT}[math.floor(a/16)][math.floor(b/16)]*16+${id.xorT}[a%16][b%16] end`,
  );
  lines.push(
    `local function ${id.rot}(b,r) if r==0 then return b end return math.floor(b/2^r)%256+(b*2^(8-r))%256 end`,
  );
  lines.push(`local ${id.ksA},${id.ksB}=${bake(seed % 65520 + 1)},${bake((seed * 7 + 13) % 65518 + 1)}`);
  lines.push(
    `local function ${id.step}() ${id.ksA}=(${id.ksA}*251+12345)%65521 ${id.ksB}=(${id.ksB}*241+54321)%65519 end`,
  );
  lines.push(`local function ${id.nbyte}() ${id.step}() return (${id.ksA}+${id.ksB}*7)%256 end`);
  lines.push(`local function ${id.nidx}() ${id.step}() return (${id.ksA}*157+${id.ksB}) end`);
  lines.push(`local ${id.box}={} for i=0,255 do ${id.box}[i]=i end`);
  lines.push(
    `for i=255,1,-1 do local j=${id.nidx}()%(i+1) ${id.box}[i],${id.box}[j]=${id.box}[j],${id.box}[i] end`,
  );
  lines.push(`local ${id.inv}={} for i=0,255 do ${id.inv}[${id.box}[i]]=i end`);
  lines.push(`local ${id.key}={${key.map((value) => bake(value)).join(",")}}`);
  lines.push(`setmetatable(${id.key},{__index=function(t,k) return rawget(t,((k-1)%#t)+1) end})`);

  // decoration: dead functions scale with the inflation level
  for (let index = 0; index < profile.junk + 1; index += 1) {
    const fn = rid("_", 5, 10);
    const arg = rid("_", 2, 3);
    const tbl = rid("_", 3, 6);
    lines.push(
      `local function ${fn}(${arg}) local ${tbl}={} for i=1,(${arg}%7)+1 do ${tbl}[i]=(i*${randomInt(7, 977)}+${bake(randomInt(3, 40000))})%65521 end return ${tbl} end`,
    );
  }

  lines.push(`local ${id.ok},${id.body}=pcall(function() return game:HttpGet("${stageUrl}") end)`);
  lines.push(
    `if not ${id.ok} or type(${id.body})~="string" then return warn("[loadbin] stage fetch failed (check your executor HttpGet)") end`,
  );
  lines.push(`local ${id.words}={} for n in string.gmatch(${id.body},"%d+") do ${id.words}[#${id.words}+1]=tonumber(n) end`);
  lines.push(`local ${id.out}={}`);
  lines.push(`for i=0,${bake(bytes.length)}-1 do`);
  lines.push(`  local word=${id.words}[math.floor(i/3)+1] or 0`);
  lines.push(`  local lane=i%3`);
  lines.push(`  local x=math.floor(word/(256^lane))%256`);
  lines.push(`  x=${id.rot}(x,(i%7)+1) x=${id.inv}[x] x=(x-${id.nbyte}()-(i%251))%256`);
  lines.push(`  x=${id.xor}(x,${id.key}[i%#${id.key}+1])`);
  lines.push(`  ${id.out}[#${id.out}+1]=string.char(x)`);
  lines.push(`end`);
  lines.push(`local ${id.src}=table.concat(${id.out}) ${id.out}=nil ${id.words}=nil`);
  lines.push(`local h1,h2=11,23`);
  lines.push(
    `for i=1,#${id.src} do local v=string.byte(${id.src},i) h1=(h1*31+v)%65521 h2=(h2*17+v)%65519 end`,
  );
  lines.push(
    `if h1~=${bake(hashA)} or h2~=${bake(hashB)} then return warn("[loadbin] staged payload integrity failed") end`,
  );
  lines.push(`local ${id.fn},${id.err}=loadstring(${id.src}) ${id.src}=nil`);
  lines.push(
    `if not ${id.fn} then return warn("[loadbin] staged build failed: "..tostring(${id.err})) end`,
  );
  lines.push(`local ok,msg=pcall(${id.fn}) if not ok then return warn("[loadbin] "..tostring(msg)) end`);

  // wrap in nested closures like the reference implementation
  let stub = lines.join("\n");
  const layers = 2;
  for (let index = 0; index < layers; index += 1) {
    const p1 = rid("_", 3, 6);
    const p2 = rid("_", 3, 6);
    const junk = rid("_", 4, 8);
    stub = `return(function(${p1},${p2},...) local ${junk}=(${p1}*${randomInt(3, 97)}+${p2})%${randomInt(1009, 99991)}
${stub}
end)(${randomInt(2, 900)},${randomInt(2, 900)},...)`;
  }

  if (options?.debug) Object.assign(options.debug, { seed, key, cipher, packed, storage: stage, hashA, hashB });
  return { stub: `${stub}\n`, stage };
}
