export type RememberedScript = {
  slug: string;
  title: string;
  editKey: string;
  savedAt: string;
};

const STORAGE_KEY = "loadbin.scripts.v1";

export function readRememberedScripts(): RememberedScript[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw) as RememberedScript[];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item) => item && typeof item.slug === "string" && typeof item.editKey === "string");
  } catch {
    return [];
  }
}

export function rememberScript(entry: Omit<RememberedScript, "savedAt">): void {
  if (typeof window === "undefined") return;
  const existing = readRememberedScripts().filter((item) => item.slug !== entry.slug);
  const next = [{ ...entry, savedAt: new Date().toISOString() }, ...existing].slice(0, 60);
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
}

export function forgetScript(slug: string): void {
  if (typeof window === "undefined") return;
  const next = readRememberedScripts().filter((item) => item.slug !== slug);
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
}
