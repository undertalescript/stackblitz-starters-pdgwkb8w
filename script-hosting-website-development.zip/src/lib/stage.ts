import { createHash } from "node:crypto";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { scripts } from "@/db/schema";
import { buildTwoStage, normalizeInflation, normalizeObfuscation } from "@/lib/obfuscate";

/** Stage payloads are only valid for a short window. */
export const STAGE_WINDOW_SECONDS = 900;

export function stageNonce(slug: string, accessToken: string, offset = 0): string {
  const window = Math.floor(Date.now() / (STAGE_WINDOW_SECONDS * 1000)) + offset;
  return createHash("sha256").update(`${slug}:${accessToken}:${window}:loadbin-stage`).digest("hex").slice(0, 24);
}

export function verifyStageNonce(slug: string, accessToken: string, nonce: string): boolean {
  return [0, -1].some((offset) => stageNonce(slug, accessToken, offset) === nonce);
}

/** Deterministic cipher material: both stages must derive identical output. */
export function deriveMaterial(slug: string, accessToken: string, nonce: string): {
  seed: number;
  key: number[];
} {
  const seedHash = createHash("sha256").update(`${slug}:${accessToken}:${nonce}:seed`).digest();
  const seed = (seedHash.readUInt32BE(0) % 65520) + 1;
  const keyHash = createHash("sha256").update(`${slug}:${accessToken}:${nonce}:key`).digest();
  const key = Array.from({ length: 16 }, (_, index) => keyHash[index]);
  return { seed, key };
}

type StageLookup = {
  ok: true;
  stub: string;
  stage: string;
} | { ok: false; status: number; body: string; reason: string };

/**
 * Everything needed to serve both stages for one script:
 *  - `stub` goes into /api/raw/:slug (contains no payload)
 *  - `stage` is served separately from /api/stage/:slug
 */
export function buildStagedBundle(input: {
  slug: string;
  code: string;
  accessToken: string;
  nonce: string;
  obfuscation: string;
  inflation: number;
  stageUrl: string;
}): { stub: string; stage: string } {
  const mode = normalizeObfuscation(input.obfuscation);
  const inflation = normalizeInflation(input.inflation);
  if (mode === "none") return { stub: input.code, stage: "" };

  const { seed, key } = deriveMaterial(input.slug, input.accessToken, input.nonce);
  return buildTwoStage(input.code, input.stageUrl, {
    inflation,
    seedOverride: seed,
    keyOverride: key,
  });
}

export async function lookupStage(
  slug: string,
  accessToken: string,
  nonce: string,
): Promise<StageLookup> {
  const rows = await db
    .select({
      code: scripts.code,
      accessToken: scripts.accessToken,
      inflation: scripts.inflation,
      disabled: scripts.disabled,
    })
    .from(scripts)
    .where(eq(scripts.slug, slug))
    .limit(1);

  const script = rows[0];
  if (!script) return { ok: false, status: 404, body: "", reason: "missing" };
  if (script.accessToken !== accessToken) return { ok: false, status: 403, body: "", reason: "signature" };
  if (!verifyStageNonce(slug, accessToken, nonce)) {
    return { ok: false, status: 403, body: "", reason: "nonce" };
  }
  if (script.disabled) return { ok: false, status: 403, body: "", reason: "disabled" };

  const { stage } = buildStagedBundle({
    slug,
    code: script.code,
    accessToken,
    nonce,
    obfuscation: "ultra",
    inflation: script.inflation,
    stageUrl: "",
  });
  return { ok: true, stub: "", stage: stage.replace(/\n/g, "") };
}
