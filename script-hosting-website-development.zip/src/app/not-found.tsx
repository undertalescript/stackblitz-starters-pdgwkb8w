import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto grid min-h-[70vh] max-w-3xl place-items-center px-5 py-16">
      <div className="card w-full p-8 text-center">
        <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-brand-2">404 · not found</p>
        <h1 className="mt-3 text-[26px] font-semibold tracking-tight text-white">这条 loadstring 不存在</h1>
        <p className="mx-auto mt-3 max-w-md text-[13px] leading-relaxed text-zinc-500">
          脚本可能已被作者删除，或者短链拼写有误。你可以回到脚本库找找看，或上传自己的脚本。
        </p>
        <pre className="mx-auto mt-5 w-full max-w-md overflow-x-auto rounded-lg border border-line bg-[#080910] px-4 py-3 text-left font-mono text-[11.5px] text-zinc-500">
          <code>{`> game:HttpGet("…/api/raw/missing")\n-- 404 · script not found`}</code>
        </pre>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <Link href="/scripts" className="btn btn-primary">浏览脚本库</Link>
          <Link href="/" className="btn btn-ghost">返回首页</Link>
        </div>
      </div>
    </div>
  );
}
