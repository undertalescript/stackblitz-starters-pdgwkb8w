import { redirect } from "next/navigation";

/**
 * The owner console now lives inside the account page.
 * Keep this route as a permanent shortcut.
 */
export default function AdminPage() {
  redirect("/account#owner");
}
