import Link from "next/link";
import type { Metadata } from "next";
import { getSiteSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

export const metadata: Metadata = { title: "站点状态", robots: { index: false, follow: false } };

export default async function MaintenancePage() {
  const settings = await getSiteSettings();

  return (
    <div className="mx-auto grid min-h-[60vh] max-w-2xl place-items-center px-5 py-16">
      <div className="card w-full p-8">
        <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-2">/ status</p>
        <h1 className="mt-2 text-[24px] font-semibold tracking-tight text-white">站点运行状态</h1>

        <div className="mt-5 space-y-2.5">
          {[
            {
              label: "脚本执行",
              value: settings.scriptsEnabled ? "正常 · 可执行" : "已由站长停止",
              ok: settings.scriptsEnabled,
            },
            {
              label: "页面浏览",
              value: settings.maintenanceMode ? "维护模式 · 部分隐藏" : "正常",
              ok: !settings.maintenanceMode,
            },
            {
              label: "源码保护",
              value: "开启 · 直链需签名",
              ok: true,
            },
          ].map((row) => (
            <div
              key={row.label}
              className="flex items-center justify-between gap-3 rounded-lg border border-line bg-white/[0.015] px-3.5 py-2.5"
            >
              <span className="text-[12.5px] text-zinc-400">{row.label}</span>
              <span
                className={`flex items-center gap-1.5 font-mono text-[11.5px] ${row.ok ? "text-lime-300" : "text-rose-300"}`}
              >
                <span className={`h-1.5 w-1.5 rounded-full ${row.ok ? "bg-lime" : "bg-rose-400"}`} />
                {row.value}
              </span>
            </div>
          ))}
        </div>

        {settings.announcement.trim() && (
          <p className="mt-4 rounded-lg border border-amber-400/25 bg-amber-400/[0.07] px-3.5 py-2.5 text-[12px] leading-relaxed text-amber-100/90">
            📢 {settings.announcement}
          </p>
        )}

        <div className="mt-5 flex flex-wrap gap-2">
          <Link href="/" className="btn btn-primary !py-2">返回首页</Link>
          <Link href="/scripts" className="btn btn-ghost !py-2">浏览脚本库</Link>
        </div>
      </div>
    </div>
  );
}
