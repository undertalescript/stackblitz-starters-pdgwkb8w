import type { Metadata } from "next";
import { UploadForm } from "@/components/upload-form";
import { getBaseUrl } from "@/lib/site";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "上传脚本",
  description: "粘贴 Luau 代码，立即生成永久可用的 loadstring 链接。",
};

export default async function NewScriptPage() {
  const baseUrl = await getBaseUrl();

  return (
    <div className="mx-auto max-w-6xl px-5 py-10">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-2">/ upload</p>
          <h1 className="mt-2 text-[30px] font-semibold tracking-tight text-white">上传脚本</h1>
          <p className="mt-2 max-w-xl text-[13.5px] leading-relaxed text-zinc-500">
            粘贴代码，我们会返回一条 <code className="font-mono text-brand-2">loadstring</code> 链接。
            无需注册，编辑密钥只会显示一次。
          </p>
        </div>
        <div className="flex items-center gap-2 rounded-xl border border-line bg-panel/60 px-3.5 py-2.5">
          <span className="h-1.5 w-1.5 rounded-full bg-lime" />
          <span className="font-mono text-[11px] text-zinc-400">storage online · no rate limit</span>
        </div>
      </div>

      <div className="mt-8">
        <UploadForm baseUrl={baseUrl} />
      </div>
    </div>
  );
}
