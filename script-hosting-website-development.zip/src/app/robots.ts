import type { MetadataRoute } from "next";
import { getBaseUrl } from "@/lib/site";

export const dynamic = "force-dynamic";

export default async function robots(): Promise<MetadataRoute.Robots> {
  const baseUrl = await getBaseUrl();

  return {
    rules: [
      {
        userAgent: "*",
        allow: ["/", "/scripts", "/new", "/docs"],
        disallow: ["/manage", "/account", "/admin", "/maintenance", "/s/*/edit", "/s/*/raw", "/api/raw", "/api/admin", "/raw", "/l"],
      },
    ],
    sitemap: `${baseUrl}/sitemap.xml`,
  };
}
