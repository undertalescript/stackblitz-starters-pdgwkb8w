import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  return Response.json(
    { ok: true, authenticated: Boolean(user), user },
    { headers: { "cache-control": "no-store" } },
  );
}
