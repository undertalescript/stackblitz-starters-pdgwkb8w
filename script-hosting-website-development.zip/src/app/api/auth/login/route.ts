import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { asString, jsonError, readJson } from "@/lib/api-helpers";
import { createSession, normalizeUsername, verifyPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const body = await readJson(request);
  const username = normalizeUsername(asString(body.username, 32));
  const password = typeof body.password === "string" ? body.password : "";

  if (!username || !password) return jsonError("请输入用户名和密码");

  const rows = await db
    .select({ id: users.id, username: users.username, passwordHash: users.passwordHash, createdAt: users.createdAt })
    .from(users)
    .where(eq(users.username, username))
    .limit(1);

  const user = rows[0];
  if (!user || !(await verifyPassword(password, user.passwordHash))) {
    return jsonError("用户名或密码不正确", 401);
  }

  await createSession(user.id);
  return Response.json({
    ok: true,
    user: { id: user.id, username: user.username, createdAt: user.createdAt },
  });
}
