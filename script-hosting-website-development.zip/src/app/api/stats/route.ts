import { ensureSeeded } from "@/db/seed";
import { getPlatformStats, getTagCloud } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const [stats, tags] = await Promise.all([getPlatformStats(), getTagCloud(12)]);

  return Response.json({
    ok: true,
    stats,
    tags,
    generatedAt: new Date().toISOString(),
  });
}
