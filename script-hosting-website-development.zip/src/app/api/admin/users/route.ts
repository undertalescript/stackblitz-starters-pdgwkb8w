import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { asString, isUniqueViolation, jsonError, readJson } from "@/lib/api-helpers";
import {
  getAdminUser,
  hashPassword,
  normalizeUsername,
  validatePassword,
  validateUsername,
} from "@/lib/auth";

export const dynamic = "force-dynamic";

const TEMP_PASSWORD = "loadbin-admin";

export async function GET() {
  const admin = await getAdminUser();
  if (!admin) return jsonError("需要站长权限", 403);

  const rows = await db
    .select({
      id: users.id,
      username: users.username,
      role: users.role,
      createdAt: users.createdAt,
      scriptCount: sql<number>`(
        select count(*)::int from scripts where scripts.owner_id = ${users.id}
      )`,
    })
    .from(users)
    .orderBy(asc(users.id));

  return Response.json({ ok: true, users: rows, current: admin.username });
}

export async function POST(request: Request) {
  const admin = await getAdminUser();
  if (!admin) return jsonError("需要站长权限", 403);

  const body = await readJson(request);
  const username = normalizeUsername(asString(body.username, 32));
  const action = body.action === "demote" ? "demote" : "promote";

  const usernameError = validateUsername(username);
  if (usernameError) return jsonError(usernameError);

  if (action === "demote") {
    if (username === admin.username) return jsonError("不能撤销自己的管理员权限");
    if (username === (process.env.ADMIN_USERNAME ?? "zasqw89071").toLowerCase()) {
      return jsonError("不能撤销主站长的权限");
    }

    const [updated] = await db
      .update(users)
      .set({ role: "user" })
      .where(eq(users.username, username))
      .returning({ id: users.id, username: users.username, role: users.role });

    if (!updated) return jsonError("该用户不存在", 404);
    return Response.json({ ok: true, user: updated });
  }

  // promote: existing account becomes admin, otherwise create it with a temp password.
  const existing = await db
    .select({ id: users.id, username: users.username, role: users.role })
    .from(users)
    .where(eq(users.username, username))
    .limit(1);

  if (existing[0]) {
    if (existing[0].role === "admin") {
      return Response.json({ ok: true, already: true, user: existing[0] });
    }
    const [updated] = await db
      .update(users)
      .set({ role: "admin" })
      .where(eq(users.id, existing[0].id))
      .returning({ id: users.id, username: users.username, role: users.role });
    return Response.json({ ok: true, user: updated });
  }

  const password = asString(body.password, 128) || TEMP_PASSWORD;
  const passwordError = validatePassword(password);
  if (passwordError) return jsonError(passwordError);

  try {
    const [created] = await db
      .insert(users)
      .values({ username, role: "admin", passwordHash: await hashPassword(password) })
      .returning({ id: users.id, username: users.username, role: users.role });

    return Response.json(
      { ok: true, created: true, user: created, tempPassword: password },
      { status: 201 },
    );
  } catch (error) {
    if (isUniqueViolation(error)) return jsonError("该用户名已存在，请重试", 409);
    console.error("[admin/users] create failed", error);
    return jsonError("添加失败，请稍后再试", 500);
  }
}
