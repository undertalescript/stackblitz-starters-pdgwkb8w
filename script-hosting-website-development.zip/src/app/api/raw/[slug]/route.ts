import { rawPreflight, serveRawScript } from "@/lib/raw-serve";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ slug: string }> };

export async function GET(request: Request, context: RouteContext) {
  const { slug } = await context.params;
  return serveRawScript(request, slug);
}

export async function HEAD(request: Request, context: RouteContext) {
  const { slug } = await context.params;
  return serveRawScript(request, slug);
}

export async function OPTIONS() {
  return rawPreflight();
}
