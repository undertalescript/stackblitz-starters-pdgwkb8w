import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { scriptLikes, scripts } from "@/db/schema";
import { jsonError, readJson, visitorHash } from "@/lib/api-helpers";

export const dynamic = "force-dynamic";

type RouteContext = { params: Promise<{ slug: string }> };

export async function POST(request: Request, context: RouteContext) {
  const { slug } = await context.params;
  const body = await readJson(request);
  const action = body.action === "unlike" ? "unlike" : "like";

  const [script] = await db
    .select({ id: scripts.id })
    .from(scripts)
    .where(eq(scripts.slug, slug))
    .limit(1);

  if (!script) return jsonError("脚本不存在", 404);

  const hash = visitorHash(request);
  let liked = action === "like";

  if (action === "like") {
    const inserted = await db
      .insert(scriptLikes)
      .values({ scriptId: script.id, visitorHash: hash })
      .onConflictDoNothing()
      .returning({ scriptId: scriptLikes.scriptId });

    if (inserted.length > 0) {
      await db
        .update(scripts)
        .set({ likes: sql`${scripts.likes} + 1` })
        .where(eq(scripts.id, script.id));
    }
    liked = true;
  } else {
    const removed = await db
      .delete(scriptLikes)
      .where(and(eq(scriptLikes.scriptId, script.id), eq(scriptLikes.visitorHash, hash)))
      .returning({ scriptId: scriptLikes.scriptId });

    if (removed.length > 0) {
      await db
        .update(scripts)
        .set({ likes: sql`greatest(${scripts.likes} - 1, 0)` })
        .where(eq(scripts.id, script.id));
    }
    liked = false;
  }

  const [row] = await db
    .select({ likes: scripts.likes })
    .from(scripts)
    .where(eq(scripts.id, script.id))
    .limit(1);

  return Response.json({ ok: true, liked, likes: row?.likes ?? 0 });
}
