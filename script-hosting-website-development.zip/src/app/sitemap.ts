import type { MetadataRoute } from "next";
import { ensureSeeded } from "@/db/seed";
import { listScripts } from "@/lib/queries";
import { getBaseUrl } from "@/lib/site";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = await getBaseUrl();

  const staticRoutes: MetadataRoute.Sitemap = [
    { url: `${baseUrl}/`, changeFrequency: "daily", priority: 1 },
    { url: `${baseUrl}/scripts`, changeFrequency: "hourly", priority: 0.9 },
    { url: `${baseUrl}/new`, changeFrequency: "weekly", priority: 0.6 },
    { url: `${baseUrl}/docs`, changeFrequency: "weekly", priority: 0.5 },
  ];

  try {
    await ensureSeeded();
    const { items } = await listScripts({ sort: "newest", perPage: 30 });
    return [
      ...staticRoutes,
      ...items.map((script) => ({
        url: `${baseUrl}/s/${script.slug}`,
        lastModified: script.updatedAt,
        changeFrequency: "weekly" as const,
        priority: 0.7,
      })),
    ];
  } catch {
    return staticRoutes;
  }
}
