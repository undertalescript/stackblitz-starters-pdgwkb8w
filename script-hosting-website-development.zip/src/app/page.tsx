import Link from "next/link";
import { ScriptCard } from "@/components/script-card";
import { ensureSeeded } from "@/db/seed";
import { formatNumber, timeAgo } from "@/lib/format";
import { getBaseUrl } from "@/lib/site";
import { getFeaturedScripts, getPlatformStats, getTagCloud, listScripts } from "@/lib/queries";

export const dynamic = "force-dynamic";

const STEPS = [
  {
    title: "粘贴脚本",
    body: "把 Luau 代码放进编辑器，支持实时语法高亮与自定义短链。",
    code: "-- your_script.lua\nprint(\"hello loadbin\")",
  },
  {
    title: "拿到签名链接",
    body: "托管完成后生成带签名的 /api/raw/:slug?key=… 地址，浏览器直接打开会被拒绝。",
    code: "https://your-host/api/raw/orbit-esp?key=•••",
  },
  {
    title: "一行执行",
    body: "只把 loadstring 交给用户，源码不会出现在浏览器里，每次调用都会记入统计。",
    code: "loadstring(game:HttpGet(url))()",
  },
];

export default async function HomePage() {
  await ensureSeeded();

  const [stats, featured, trending, tags, baseUrl] = await Promise.all([
    getPlatformStats(),
    getFeaturedScripts(3),
    listScripts({ sort: "trending", perPage: 5 }),
    getTagCloud(10),
    getBaseUrl(),
  ]);

  const demoSlug = trending.items[0]?.slug ?? featured[0]?.slug ?? "orbit-esp-9f3k";
  const demoUrl = `${baseUrl}/api/raw/${demoSlug}?key=••••••••`;

  const statCards = [
    { label: "托管脚本", value: formatNumber(stats.scripts), hint: `${stats.week} 个新增于本周` },
    { label: "总浏览量", value: formatNumber(stats.views), hint: "脚本页访问" },
    { label: "loadstring 调用", value: formatNumber(stats.runs), hint: "raw 接口执行次数" },
    { label: "累计收藏", value: formatNumber(stats.likes), hint: `${stats.comments} 条评论` },
  ];

  return (
    <div className="mx-auto max-w-6xl px-5">
      {/* Hero */}
      <section className="relative grid gap-12 pb-16 pt-14 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:pt-20">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-line bg-white/[0.03] px-3 py-1.5 text-[11.5px] text-zinc-400">
            <span className="h-1.5 w-1.5 rounded-full bg-lime shadow-[0_0_10px_#c8f75a]" />
            Luau 脚本托管 · 源码保护 · 永久短链
          </div>

          <h1 className="mt-6 text-[clamp(2.2rem,5.4vw,3.7rem)] font-semibold leading-[1.08] tracking-tight text-white">
            一行 loadstring，
            <br />
            <span className="text-gradient">托管你的脚本。</span>
          </h1>

          <p className="mt-5 max-w-lg text-[14.5px] leading-relaxed text-zinc-400">
            loadbin 把 Luau 脚本变成一条永久链接，并默认开启源码保护：把 raw 地址粘贴到浏览器会被直接拒绝，
            只有执行器携带签名才能读取代码，用户依然只需要一行{" "}
            <code className="rounded bg-white/[0.06] px-1.5 py-0.5 font-mono text-[12px] text-lime-300">loadstring</code> 就能运行。
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <Link href="/new" className="btn btn-primary !px-5 !py-3">
              免费托管脚本
              <span className="text-base leading-none">→</span>
            </Link>
            <Link href="/scripts" className="btn btn-ghost !px-5 !py-3">
              浏览脚本库
            </Link>
          </div>

          <div className="mt-7 flex flex-wrap items-center gap-x-5 gap-y-2 text-[11.5px] text-zinc-500">
            <span className="flex items-center gap-1.5"><span className="text-lime">✓</span> 注册免费</span>
            <span className="flex items-center gap-1.5"><span className="text-lime">✓</span> 源码防直接访问</span>
            <span className="flex items-center gap-1.5"><span className="text-lime">✓</span> 不限带宽</span>
            <span className="flex items-center gap-1.5"><span className="text-lime">✓</span> 支持自定义短链</span>
            <span className="flex items-center gap-1.5"><span className="text-lime">✓</span> 开放 REST API</span>
          </div>

          <div className="mt-8 flex flex-wrap gap-2">
            {["Solara", "Wave", "Delta", "Xeno", "Swift"].map((executor) => (
              <span key={executor} className="chip !text-zinc-500">
                {executor}
              </span>
            ))}
            <span className="chip !border-transparent !bg-transparent !text-zinc-600">兼容所有 HttpGet 执行器</span>
          </div>
        </div>

        {/* Terminal */}
        <div className="relative">
          <div className="absolute -inset-4 -z-10 rounded-[2rem] bg-brand/15 blur-3xl" />
          <div className="card glow-brand overflow-hidden">
            <div className="flex items-center gap-2 border-b border-line bg-white/[0.02] px-4 py-3">
              <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
              <span className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
              <span className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
              <span className="ml-2 font-mono text-[11px] text-zinc-500">executor — loadbin</span>
              <span className="ml-auto rounded border border-line px-1.5 py-0.5 font-mono text-[9.5px] text-zinc-500">
                luau
              </span>
            </div>

            <div className="space-y-3 px-4 py-5 font-mono text-[12.5px] leading-relaxed">
              <p className="text-zinc-600">$ edit loadstring.lua</p>
              <p className="break-all text-zinc-300">
                <span className="text-violet-300">loadstring</span>
                <span className="text-zinc-500">(</span>game
                <span className="text-zinc-500">:</span>
                <span className="text-cyan-200">HttpGet</span>
                <span className="text-zinc-500">(</span>
                <span className="text-lime-300">&quot;{demoUrl}&quot;</span>
                <span className="text-zinc-500">))()</span>
                <span className="cursor-blink ml-1 inline-block h-3.5 w-2 translate-y-0.5 bg-brand-2" />
              </p>
              <div className="rounded-lg border border-line/80 bg-black/30 p-3">
                <div className="flex items-center justify-between text-[10.5px]">
                  <span className="flex items-center gap-2 text-zinc-500">
                    <span className="rounded bg-lime/15 px-1.5 py-0.5 font-bold text-lime">200</span>
                    GET /api/raw/{demoSlug}?key=•••·
                  </span>
                  <span className="text-zinc-600">text/plain · no-store</span>
                </div>
                <pre className="mt-2 overflow-x-auto text-[11.5px] text-zinc-400">
                  <code>{`-- ${trending.items[0]?.title ?? "Orbit ESP"}\nprint("[loadbin] injected ✓")`}</code>
                </pre>
              </div>
              <p className="text-lime-300/90">
                [loadbin] injected ✓ <span className="text-zinc-600">· 12ms · edge cached</span>
              </p>
            </div>

            <div className="grid grid-cols-3 divide-x divide-line border-t border-line bg-white/[0.015]">
              {[
                { k: "调用次数", v: formatNumber(trending.items[0]?.runs ?? 0) },
                { k: "今日延迟", v: "42ms" },
                { k: "可用性", v: "99.98%" },
              ].map((item) => (
                <div key={item.k} className="px-4 py-3">
                  <p className="font-mono text-[10px] uppercase tracking-wider text-zinc-600">{item.k}</p>
                  <p className="mt-1 font-mono text-[13px] text-zinc-200">{item.v}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="float-slow absolute -bottom-6 -left-4 hidden rounded-xl border border-line bg-panel/95 px-3.5 py-2.5 shadow-2xl backdrop-blur sm:block">
            <p className="font-mono text-[10px] uppercase tracking-wider text-zinc-500">最新托管</p>
            <p className="mt-0.5 max-w-[180px] truncate text-[12px] text-zinc-200">
              {trending.items[0]?.title ?? "—"}
            </p>
            <p className="font-mono text-[10px] text-lime-300">
              +{formatNumber(trending.items[0]?.runs ?? 0)} runs
            </p>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {statCards.map((stat) => (
          <div key={stat.label} className="card px-4 py-4">
            <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-zinc-500">{stat.label}</p>
            <p className="mt-2 text-[24px] font-semibold leading-none tracking-tight text-white">{stat.value}</p>
            <p className="mt-1.5 text-[11px] text-zinc-600">{stat.hint}</p>
          </div>
        ))}
      </section>

      {/* Featured */}
      <section className="mt-20">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-2">/ featured</p>
            <h2 className="mt-2 text-[24px] font-semibold tracking-tight text-white">社区精选脚本</h2>
            <p className="mt-1.5 text-[13px] text-zinc-500">按收藏与调用量挑选的高质量 Luau 脚本。</p>
          </div>
          <Link href="/scripts" className="btn btn-ghost !py-2">
            全部脚本 <span className="text-zinc-500">→</span>
          </Link>
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {featured.map((script) => (
            <ScriptCard key={script.slug} script={script} />
          ))}
        </div>
      </section>

      {/* Trending + tags */}
      <section className="mt-20 grid gap-5 lg:grid-cols-[1.6fr_1fr]">
        <div className="card overflow-hidden">
          <div className="flex items-center justify-between border-b border-line px-5 py-4">
            <div>
              <h2 className="text-[15px] font-semibold text-white">热门排行</h2>
              <p className="mt-0.5 text-[11.5px] text-zinc-500">综合调用量、浏览量指数排序</p>
            </div>
            <span className="chip font-mono">trending</span>
          </div>
          <div className="divide-y divide-line/70">
            {trending.items.map((script, index) => (
              <Link
                key={script.slug}
                href={`/s/${script.slug}`}
                className="group flex items-center gap-3 px-5 py-3.5 transition-colors hover:bg-white/[0.025]"
              >
                <span className="w-5 shrink-0 font-mono text-[13px] text-zinc-600 group-hover:text-brand-2">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg border border-line bg-white/[0.02] font-mono text-[11px] text-zinc-500">
                  {script.language === "luau" ? "L" : "lua"}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13px] text-zinc-200 group-hover:text-white">
                    {script.title}
                  </span>
                  <span className="mt-0.5 block truncate font-mono text-[10.5px] text-zinc-600">
                    /{script.slug} · {timeAgo(script.updatedAt)}
                  </span>
                </span>
                <span className="hidden shrink-0 items-center gap-3 font-mono text-[11px] text-zinc-500 sm:flex">
                  <span>▶ {formatNumber(script.runs)}</span>
                  <span className="text-rose-300/80">♥ {formatNumber(script.likes)}</span>
                </span>
              </Link>
            ))}
            {trending.items.length === 0 && (
              <p className="px-5 py-10 text-center text-[13px] text-zinc-500">还没有公开脚本，成为第一个作者吧。</p>
            )}
          </div>
        </div>

        <div className="space-y-5">
          <div className="card p-5">
            <h2 className="text-[15px] font-semibold text-white">按标签浏览</h2>
            <p className="mt-0.5 text-[11.5px] text-zinc-500">找到你正在玩的游戏与需要的功能</p>
            <div className="mt-4 flex flex-wrap gap-2">
              {tags.map((tag) => (
                <Link key={tag.name} href={`/scripts?tag=${encodeURIComponent(tag.name)}`} className="chip hover:border-brand/50 hover:text-brand-2">
                  {tag.name}
                  <span className="font-mono text-[10px] text-zinc-600">{tag.count}</span>
                </Link>
              ))}
            </div>
          </div>

          <div className="card overflow-hidden">
            <div className="border-b border-line px-5 py-4">
              <h2 className="text-[15px] font-semibold text-white">给开发者</h2>
              <p className="mt-0.5 text-[11.5px] text-zinc-500">纯 HTTP 接口，随意集成</p>
            </div>
            <pre className="overflow-x-auto px-5 py-4 font-mono text-[11.5px] leading-relaxed text-zinc-400">
              <code>{`GET /api/raw/:slug
GET /api/scripts?tag=自动
POST /api/scripts`}</code>
            </pre>
            <div className="border-t border-line px-5 py-3.5">
              <Link href="/docs" className="text-[12px] text-brand-2 hover:underline">
                阅读 API 文档 →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Steps */}
      <section className="mt-20">
        <div className="flex items-end justify-between gap-4">
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-brand-2">/ how it works</p>
            <h2 className="mt-2 text-[24px] font-semibold tracking-tight text-white">三步上线你的脚本</h2>
          </div>
          <span className="chip font-mono">~30s</span>
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {STEPS.map((step, index) => (
            <div key={step.title} className="card card-hover p-5">
              <div className="flex items-center justify-between">
                <span className="grid h-7 w-7 place-items-center rounded-lg border border-brand/40 bg-brand/10 font-mono text-[11px] text-brand-2">
                  0{index + 1}
                </span>
                <span className="font-mono text-[10px] uppercase tracking-wider text-zinc-600">step</span>
              </div>
              <h3 className="mt-4 text-[15px] font-semibold text-white">{step.title}</h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-zinc-500">{step.body}</p>
              <pre className="mt-4 overflow-x-auto rounded-lg border border-line bg-[#07080d] px-3 py-2 font-mono text-[11px] leading-relaxed text-lime-300/90">
                <code>{step.code}</code>
              </pre>
            </div>
          ))}
        </div>
      </section>

      {/* CTA */}
      <section className="relative mt-20 overflow-hidden rounded-2xl border border-brand/30 bg-gradient-to-br from-brand/[0.16] via-[#0b0c13] to-[#0b0c13] px-6 py-12 text-center">
        <div className="absolute inset-0 grid-bg opacity-20" />
        <div className="relative">
          <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-brand-2">start building</p>
          <h2 className="mx-auto mt-3 max-w-xl text-[clamp(1.6rem,3.4vw,2.2rem)] font-semibold leading-tight text-white">
            现在就把你的脚本托管成一条永久链接
          </h2>
          <p className="mx-auto mt-3 max-w-lg text-[13px] text-zinc-400">
            免费、无需注册、支持私有短链。上传后可随时用编辑密钥更新代码，链接保持不变。
          </p>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <Link href="/new" className="btn btn-lime !px-5 !py-3">上传脚本</Link>
            <Link href="/docs" className="btn btn-ghost !px-5 !py-3">查看接口文档</Link>
          </div>
        </div>
      </section>
    </div>
  );
}
